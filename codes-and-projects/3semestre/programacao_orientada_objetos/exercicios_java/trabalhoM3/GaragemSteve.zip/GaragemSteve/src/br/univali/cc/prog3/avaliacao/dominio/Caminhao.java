/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.dominio;

/**
 *
 * @author 7853653
 */
public class Caminhao extends VeiculoTerrestre implements Veiculo {
    
    private double capacidadeCarga;

    public Caminhao(double capacidadeCarga, String modelo, String placa) {
        super(modelo, placa);
        this.capacidadeCarga = capacidadeCarga;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    @Override
    public String detalhar() {
        return "\nModelo: " + modelo + "\nPlaca: " + placa + "\nMotorista: " + motorista + "\nCapacidade de carga: " + capacidadeCarga + "kg";
    }
    
    @Override
    public String obterDescricaoVeiculo() {
        return "Caminhão: " + detalhar();
    }
    
}
