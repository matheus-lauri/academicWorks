/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.dominio;

/**
 *
 * @author 7853653
 */
public class Iate implements Veiculo {
    
    private String nome;
    private String capitao;

    public Iate(String nome) {
        this.nome = nome;
    }

    public void setCapitao(String capitao) {
        this.capitao = capitao;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String obterDescricaoVeiculo() {
        return "Iate: "+ "\nNome: " + getNome() + "\nCapitão: " + capitao;
    }
    
}
