/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.dominio;
/**
 *
 * @author 7853653
 */
public class Galpao {

    private Veiculo veiculos[] = new Veiculo[999];
    private int contadorVeiculos = 0;

    public Galpao() {
    }

    public void adicionarVeiculo(Veiculo veiculo){
        this.veiculos[contadorVeiculos++] = veiculo;
    }
    
    public String imprimirRelacaoVeiculos(){
        String message = "";
        for (Veiculo veiculo : veiculos) {
            if (veiculo != null) {
                message = message + veiculo.obterDescricaoVeiculo() + "\n\n";
            }
        }
        if("".equals(message)){
            return "Galpao Vazio";
        }else{
            return message;
        }
    }
    
}
