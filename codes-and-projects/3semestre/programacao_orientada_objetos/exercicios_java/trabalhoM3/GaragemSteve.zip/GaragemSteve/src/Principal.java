
import br.univali.cc.prog3.avaliacao.dominio.Galpao;
import br.univali.cc.prog3.avaliacao.view.GalpaoGUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 7853653
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Galpao galpao = new Galpao();
        GalpaoGUI galpaoGUI = new GalpaoGUI(galpao);
        galpaoGUI.menu();
    }
    
}
