/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.dominio;

/**
 *
 * @author 7853653
 */
public class Carro extends VeiculoTerrestre implements Veiculo{
    
    private double potencia;

    public Carro(double potencia, String modelo, String placa) {
        super(modelo, placa);
        this.potencia = potencia;
    }

    public double getPotencia() {
        return potencia;
    }
    
    @Override
    public String detalhar() {
        return "\nModelo: " + modelo + "\nPlaca: " + placa + "\nMotorista: " + motorista + "\nPotência: " + potencia + "cv";
    }

    @Override
    public String obterDescricaoVeiculo() {
        return "Carro: " + detalhar();
    }
    
}
