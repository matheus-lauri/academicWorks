/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.dominio;

/**
 *
 * @author 7853653
 */
public class Helicoptero implements Veiculo {
    
    private String modelo;
    private String sigla;
    private String piloto;

    public Helicoptero(String modelo, String sigla) {
        this.modelo = modelo;
        this.sigla = sigla;
    }

    public void setPiloto(String piloto) {
        this.piloto = piloto;
    }
    
    public String detalhar(){
        return "\nModelo: " + modelo + "\nSigla: " + sigla + "\nPiloto: " + piloto;
    }

    @Override
    public String obterDescricaoVeiculo() {
        return "Helicoptero: " + detalhar();
    }
    
}
