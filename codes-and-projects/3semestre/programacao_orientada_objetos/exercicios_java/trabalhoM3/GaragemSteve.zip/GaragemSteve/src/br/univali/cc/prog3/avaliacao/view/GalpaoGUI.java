/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.cc.prog3.avaliacao.view;
import br.univali.cc.prog3.avaliacao.dominio.Caminhao;
import br.univali.cc.prog3.avaliacao.dominio.Carro;
import br.univali.cc.prog3.avaliacao.dominio.Galpao;
import br.univali.cc.prog3.avaliacao.dominio.Helicoptero;
import br.univali.cc.prog3.avaliacao.dominio.Iate;
import javax.swing.JOptionPane;

/**
 *
 * @author 7853653
 */
public class GalpaoGUI {
    
    private Galpao galpao;
    
    public String lerValor(String rotulo) {
        return JOptionPane.showInputDialog(null,rotulo);
    }

    public String lerValor(String rotulo, String[] opcoes) {
        return (String) JOptionPane.showInputDialog(null, null, rotulo, JOptionPane.QUESTION_MESSAGE,null, opcoes,null);
    }
    
    public void escreverValor(String valor) {
        JOptionPane.showMessageDialog(null, valor);
    }

    public GalpaoGUI(Galpao galpao) {
        this.galpao = galpao;
    }

    public void menu() {
        char opcao;
        do {
            String[] opcoes = {
                "1 - Adicionar um carro ao galpao",
                "2 - Adicionar um caminhão ao galpao",
                "3 - Adicionar um iate ao galpao",
                "4 - Adicionar um helicoptero ao galpao",
                "5 - Imprimir todos os veiculos do galpao"
            };
            String valorSelecionado = this.lerValor("Selecione uma opção Sr. Steve Harris",opcoes);
            if (valorSelecionado == null) {
                opcao = 'S';
            } else {
                opcao = valorSelecionado.toUpperCase().charAt(0);
            }
            
            switch (opcao) {
                case '1': adicionarCarro();break;
                case '2': adicionarCaminhao();break;
                case '3': adicionarIate();break;
                case '4': adicionarHelicoptero();break;
                case '5': imprimirVeiculo();break;
            }
        } while (opcao != 'S');
    }

    private void adicionarCarro() {
        String modelo = lerValor("Insira o modelo:");
        String placa = lerValor("Insira a placa:");
        double potencia = Double.parseDouble(lerValor("Insira a potencia(cv):"));
        Carro carro = new Carro(potencia, modelo, placa);
        String motorista = lerValor("Insira o nome do motorista:");
        carro.setMotorista(motorista);
        this.galpao.adicionarVeiculo(carro);
    }

    private void adicionarCaminhao() {
        String modelo = lerValor("Insira o modelo:");
        String placa = lerValor("Insira a placa:");
        double capacidadeCarga = Double.parseDouble(lerValor("Insira a capacidade de carga(kg):"));
        Caminhao caminhao = new Caminhao(capacidadeCarga, modelo, placa);
        String motorista = lerValor("Insira o nome do motorista:");
        caminhao.setMotorista(motorista);
        this.galpao.adicionarVeiculo(caminhao);
    }

    private void adicionarIate() {
        String nome = lerValor("Insira o nome do iate:");
        Iate iate = new Iate(nome);
        String capitao = lerValor("Insira o nome do capitao:");
        iate.setCapitao(capitao);
        this.galpao.adicionarVeiculo(iate);
    }

    private void adicionarHelicoptero() {
        String modelo = lerValor("Insira o modelo:");
        String sigla = lerValor("Insira a sigla:");
        Helicoptero helicoptero = new Helicoptero(modelo, sigla);
        String piloto = lerValor("Insira o nome do piloto:");
        helicoptero.setPiloto(piloto);
        this.galpao.adicionarVeiculo(helicoptero);
    }
    
    private void imprimirVeiculo(){
        escreverValor(this.galpao.imprimirRelacaoVeiculos());
    }
    
}
