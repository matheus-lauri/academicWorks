package gals;

import java.util.HashMap;
import java.util.Stack;

public class Semantico implements Constants {

    Stack<Integer> pilha = new Stack<Integer>();
    HashMap<String, Integer> variaveis = new HashMap<String, Integer>();

    String variavelAtual;

    public void executeAction(int action, Token token) throws SemanticError {
        //System.out.println("Acao #" + action + ", Token: " + token.getLexeme());

        Integer aux1 = 0, aux2 = 0;
        switch (action) {
            //numeros binarios
            case 1:
                pilha.push(Integer.valueOf(token.getLexeme()));
                break;
            //salvar variavel na pilha
            case 2:
                if (variaveis.containsKey(token.getLexeme())) {
                    pilha.push(variaveis.get(token.getLexeme()));
                } else {
                    System.out.println("Case2");
                }
                break;
            //soma
            case 3:
                aux1 = pilha.pop();
                aux2 = pilha.pop();
                pilha.push(aux1 + aux2);
                //System.out.println(variavelAtual);
                break;
            //subtracao
            case 4:
                aux1 = pilha.pop();
                aux2 = pilha.pop();
                pilha.push(aux1 - aux2);
                //System.out.println(variavelAtual);
                break;
            //multiplicacao
            case 5:
                System.out.println("5");
                aux1 = pilha.pop();
                System.out.println("li aux1");
                aux2 = pilha.pop();
                System.out.println("li aux2");
                pilha.push(aux1 * aux2);
                //System.out.println(variavelAtual);
                break;
            //divisao
            case 6:
                aux1 = pilha.pop();
                aux2 = pilha.pop();
                pilha.push(aux1 / aux2);
                //System.out.println(variavelAtual);
                break;
            //exponenciacao
            case 7:
                aux1 = pilha.pop();
                aux2 = pilha.pop();
                pilha.push((int) Math.pow(aux1, aux2));
                //System.out.println(variavelAtual);
                break;
            //logaritmo
            case 8:
                aux1 = pilha.pop();
                pilha.push((int) Math.log(aux1) / (int) Math.log(aux2));
                //System.out.println(variavelAtual);              
                break;
            //ler variavel atual
            case 9:
                variavelAtual = token.getLexeme();
                break;
            //atribuição de valor da variavel atual
            case 10:
                variaveis.put(variavelAtual, pilha.pop());
                break;
            case 11:
                System.out.println("Resultado: " + Integer.toBinaryString(variaveis.get(variavelAtual)));
                break;
        }

    }
}
