package Principal;

import gals.*;
import java.io.IOException;
import java.io.StringReader;
public class Main {
    public static void main(String[] args) throws IOException{
         
        try
        {
           //Lexico lexico = new Lexico("A = 10; B = 11; B = 111 + A * B; Show (B);");
           Lexico lexico = new Lexico(new StringReader("A = 10; B = 11; B = 111 + A * B; Show (B);"));
           
           Sintatico sintatico = new Sintatico();
           Semantico semantico = new Semantico();
           sintatico.parse(lexico, semantico);
        }
            catch ( LexicalError | SyntaticError | SemanticError e )
            {
                System.out.println("Comando não identificado.");
            }
  }
}
