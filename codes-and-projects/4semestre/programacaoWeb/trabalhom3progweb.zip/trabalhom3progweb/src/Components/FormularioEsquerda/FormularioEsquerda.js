import "./FormularioEsquerda.css";
import Campo from "../Campo/Campo";
import Flag from "../Flag/Flag";
import Botao from "../Botao/Botao";

function FormularioEsquerda(props) {
  return (
    <div className="formularioEsquerda">
      <form>
        <h1> Contato </h1>
        <Campo label="Nome:" tipo="pequeno" />

        <Campo label="Email:" tipo="pequeno" />

        <Campo label="Assunto:" tipo="pequeno" />

        <Campo label="Mensagem:" tipo="grande" />

        <Flag
          label="Termos e Condições:"
          descricao="Habilitando esta opção você aceita e concorda com os nossos termos."
        />

        <Botao texto="Enviar" />
      </form>
    </div>
  );
}

export default FormularioEsquerda;
