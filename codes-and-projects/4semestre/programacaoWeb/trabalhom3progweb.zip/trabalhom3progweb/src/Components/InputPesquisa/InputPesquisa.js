import "./InputPesquisa.css";

function BotaoPesquisa() {
  return (
    <div className="inputPesquisa">
      <input type="text" placeholder="Search.." name="search" />
    </div>
  );
}

export default BotaoPesquisa;
