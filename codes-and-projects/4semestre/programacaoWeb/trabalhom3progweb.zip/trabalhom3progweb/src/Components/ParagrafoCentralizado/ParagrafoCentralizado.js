import "./ParagrafoCentralizado.css";

function ParagrafoCentralizado() {
  return (
    <div className="paragrafoCentralizado">
      <p>
        Somos uma equipe de 8 estagiários do projeto Conexão Panvel, uma
        parceria entre a Faccat e PanVel que tem como objetivo desenvolver…
      </p>
    </div>
  );
}

export default ParagrafoCentralizado;
