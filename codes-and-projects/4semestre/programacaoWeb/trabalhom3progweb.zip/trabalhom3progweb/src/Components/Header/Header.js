import "./Header.css";

function Header() {
  return (
    <header>
      <img src="./imagens/logo.png" alt="logo" />
      <nav>
        <ul>
          <li type="none">
            <a href="#">Página Inicial</a>
          </li>
          <li type="none">
            <div class="dropdown">
              <button>Categorias</button>
              <div class="dropdown-options">
                <a href="#">Assuntos Gerais</a>
                <a href="#">Projeto Conexao Panvel</a>
              </div>
            </div>
          </li>
          <li type="none">
            <a href="#">Quem somos</a>
          </li>
          <li type="none">
            <a href="#">Passou por aqui</a>
          </li>
          <li type="none">
            <a href="#">Contato</a>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
