import "./Flag.css";

function Flag(props) {
  return (
    <div className="termos" id={props.tipo}>
      <label> {props.label} </label>
      <div id="flag">
        <input type="checkbox" id="finalizado" />
        <label for="finalizado"> {props.descricao} </label>
      </div>
    </div>
  );
}

export default Flag;
