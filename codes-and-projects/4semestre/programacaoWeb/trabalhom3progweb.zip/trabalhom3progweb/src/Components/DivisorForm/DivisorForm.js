import "./DivisorForm.css";

function DivisorForm(props) {
  return (
    <div className="hr-container">
      <hr className="centered-hr" />
      <div className="centered-text">{props.texto}</div>
      <hr className="centered-hr" />
    </div>
  );
}

export default DivisorForm;
