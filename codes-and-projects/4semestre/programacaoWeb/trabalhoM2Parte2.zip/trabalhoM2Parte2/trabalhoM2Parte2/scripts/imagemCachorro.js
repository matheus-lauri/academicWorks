async function getDogImages() {
  const apiUrl = "https://api.thedogapi.com/v1/images/search?limit=10";

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (data.length > 0) {
      const dogImagesContainer = document.getElementById("dog-images");

      data.forEach((image) => {
        const img = document.createElement("img");
        img.src = image.url;
        img.alt = "Cachorro Aleatório";
        img.style.width = "300px";
        img.style.height = "300px";
        img.style.margin = "5px";
        img.style.border = "5px solid #2B3035";

        dogImagesContainer.appendChild(img);
      });
    } else {
      console.error("Nenhuma imagem de cachorro encontrada.");
    }
  } catch (error) {
    console.error("Ocorreu um erro ao buscar imagens de cachorro:", error);
  }
}

window.addEventListener("load", getDogImages);
getDogImages;
