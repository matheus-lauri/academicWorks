function enviarEmail(event) {
  let elementoEmail = document.getElementById("inputEmail").value;

  const apiKey = "6928e1df776cf28a8918eedc2e17b2f6-324e0bb2-e7cb3224";

  const apiUrl =
    "https://api.mailgun.net/v3/sandboxb00614d7529d459ba616bc898a4b2a9a.mailgun.org/messages";

  const data = {
    from: "Mailgun Sandbox <postmaster@sandboxd87a6f292e0d46b0afee3caf70abd129.mailgun.org>",
    to: elementoEmail,
    subject: "Hello",
    text: "Testing some Mailgun awesomeness!",
  };

  fetch(apiUrl, {
    method: "POST",
    headers: {
      Authorization: "Basic " + btoa("api:" + apiKey),
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams(data).toString(),
  })
    .then((response) => response.json())
    .then((data) => console.log(data))
    .catch((error) => console.error("Erro: ", error));
}
