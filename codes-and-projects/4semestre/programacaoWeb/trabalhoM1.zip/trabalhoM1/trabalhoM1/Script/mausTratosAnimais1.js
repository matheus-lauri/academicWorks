function avancarPagina(event) {
  // Coleta os valores dos inputs
  let nome = document.getElementById("nome").value;
  let endereco = document.getElementById("endereco").value;
  let telefone = document.getElementById("telefone").value;
  let email = document.getElementById("email").value;
  let local = document.getElementById("local").value;
  let dataHora = document.getElementById("data_hora").value;

  // Verifica se os campos required estão vazios
  if (!nome || !endereco || !telefone || !email || !local || !dataHora) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Salva os valores no Local Storage
    localStorage.setItem("nome", nome);
    localStorage.setItem("endereco", endereco);
    localStorage.setItem("telefone", telefone);
    localStorage.setItem("email", email);
    localStorage.setItem("local", local);
    localStorage.setItem("dataHora", dataHora);
    return true;
  }
}
