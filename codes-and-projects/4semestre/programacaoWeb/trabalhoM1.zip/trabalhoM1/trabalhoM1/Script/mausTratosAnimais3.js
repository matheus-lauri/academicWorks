document.addEventListener("DOMContentLoaded", function () {
  // Recupere os valores do Local Storage
  let nome = localStorage.getItem("nome");
  let endereco = localStorage.getItem("endereco");
  let telefone = localStorage.getItem("telefone");
  let email = localStorage.getItem("email");
  let local = localStorage.getItem("local");
  let dataHora = localStorage.getItem("dataHora");
  let descricao = localStorage.getItem("descricao");
  let especie = localStorage.getItem("especie");
  let numero_animais = localStorage.getItem("numero_animais");
  let descricao_animal = localStorage.getItem("descricao_animal");
  let informacoes_relevantes = localStorage.getItem("informacoes_relevantes");

  // Preencha os campos do relatório com os valores recuperados
  if (nome != "") {
    document.getElementById("nome").textContent = nome;
  } else {
    document.getElementById("nome").textContent = "N/A";
  }
  if (endereco != "") {
    document.getElementById("endereco").textContent = endereco;
  } else {
    document.getElementById("endereco").textContent = "N/A";
  }
  if (telefone != "") {
    document.getElementById("telefone").textContent = telefone;
  } else {
    document.getElementById("telefone").textContent = "N/A";
  }
  if (email != "") {
    document.getElementById("email").textContent = email;
  } else {
    document.getElementById("email").textContent = "N/A";
  }
  if (local != "") {
    document.getElementById("local").textContent = local;
  } else {
    document.getElementById("local").textContent = "N/A";
  }

  if (dataHora != "") {
    document.getElementById("data_hora").textContent = dataHora;
  } else {
    document.getElementById("data_hora").textContent = "N/A";
  }
  if (descricao != "") {
    document.getElementById("descricao").textContent = descricao;
  } else {
    document.getElementById("descricao").textContent = "N/A";
  }
  if (especie != "") {
    document.getElementById("especie").textContent = especie;
  } else {
    document.getElementById("especie").textContent = "N/A";
  }
  if (numero_animais != "") {
    document.getElementById("numero_animais").textContent = numero_animais;
  } else {
    document.getElementById("numero_animais").textContent = "N/A";
  }
  if (descricao_animal != "") {
    document.getElementById("descricao_animal").textContent = descricao_animal;
  } else {
    document.getElementById("descricao_animal").textContent = "N/A";
  }
  if (informacoes_relevantes != "") {
    document.getElementById("informacoes_relevantes").textContent =
      informacoes_relevantes;
  } else {
    document.getElementById("informacoes_relevantes").textContent = "N/A";
  }
});

function validarFormulario() {
  const formulario = document.getElementById("meuFormulario");
  const checkbox = document.getElementById("declaracao");
  const submitBtn = document.getElementById("submitBtn");

  submitBtn.addEventListener("click", function () {
    if (!checkbox.checked) {
      alert("Clique na caixa de seleção para declarar as informações.");
    } else {
      alert(
        "Parabéns! Você declarou as informações, mas nada foi enviado pois não temos banco :("
      );
    }
  });
}

document.addEventListener("DOMContentLoaded", validarFormulario);
