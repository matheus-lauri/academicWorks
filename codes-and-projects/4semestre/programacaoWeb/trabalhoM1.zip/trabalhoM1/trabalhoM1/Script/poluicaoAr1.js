function avancarPagina(event) {
  // Coleta os valores dos inputs
  let nome = document.getElementById("nome").value;
  let email = document.getElementById("email").value;
  let telefone = document.getElementById("telefone").value;
  let local = document.getElementById("local").value;

  // Verifica se os campos required estão vazios
  if (!nome || !email || !telefone || !local) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Salva os valores no Local Storage
    localStorage.setItem("nome", nome);
    localStorage.setItem("email", email);
    localStorage.setItem("telefone", telefone);
    localStorage.setItem("local", local);
    return true;
  }
}
