function avancarPagina() {
  const opcoes = document.getElementsByName("opcao");
  let opcaoSelecionada = "";

  for (const opcao of opcoes) {
    if (opcao.checked) {
      opcaoSelecionada = opcao.value;
      break;
    }
  }

  localStorage.setItem("tipoDenuncia", opcaoSelecionada);

  if (opcaoSelecionada == "poluicaoAgua") {
    window.location.href = "poluicaoAgua1.html";
  } else if (opcaoSelecionada == "mausTratosAnimais") {
    window.location.href = "mausTratosAnimais1.html";
  } else if (opcaoSelecionada == "poluicaoAr") {
    window.location.href = "poluicaoAr1.html";
  } else if (opcaoSelecionada == "desmatamentoIlegal") {
    window.location.href = "desmatamentoIlegal1.html";
  } else {
    alert("Opção inválida, por favor selecione uma opção!");
  }
}
