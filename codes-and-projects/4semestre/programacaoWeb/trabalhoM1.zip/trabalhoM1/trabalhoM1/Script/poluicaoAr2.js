function avancarPagina(event) {
  // Obtenha referências para os campos de entrada
  let data = document.getElementById("data").value;
  let descricao = document.getElementById("descricao").value;
  let impacto_ambiental = document.getElementById("impacto_ambiental").value;

  if (!data || !descricao || !impacto_ambiental) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Obtenha o valor do campo opcional
    let testemunha = document.getElementById("testemunha").value;

    // Salva os valores no Local Storage
    localStorage.setItem("data", data);
    localStorage.setItem("descricao", descricao);
    localStorage.setItem("impacto_ambiental", impacto_ambiental);
    localStorage.setItem("testemunha", testemunha);
    // Habilita o link para permitir o redirecionamento
    return true;
  }
}
