function avancarPagina(event) {
  let nome = document.getElementById("nome").value;
  let email = document.getElementById("email").value;
  let local = document.getElementById("local").value;
  let descricao = document.getElementById("descricao").value;

  // Verifica se os campos required estão vazios
  if (!nome || !email || !local || !descricao) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Salvar dados no Local Storage
    localStorage.setItem("nome", nome);
    localStorage.setItem("email", email);
    localStorage.setItem("local", local);
    localStorage.setItem("descricao", descricao);
    return true;
  }
}
