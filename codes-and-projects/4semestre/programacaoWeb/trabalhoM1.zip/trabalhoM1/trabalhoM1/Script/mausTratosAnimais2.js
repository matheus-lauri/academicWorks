function proximaPagina(event) {
  // Obtenha referências para os campos de entrada
  let descricao = document.getElementById("descricao").value;
  let especie = document.getElementById("especie").value;
  let numero_animais = document.getElementById("numero_animais").value;
  let descricao_animal = document.getElementById("descricao_animal").value;

  if (!descricao || !especie || !numero_animais || !descricao_animal) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Obtenha o valor do campo opcional
    let informacoes_relevantes = document.getElementById(
      "informacoes_relevantes"
    ).value;

    // Salva os valores no Local Storage
    localStorage.setItem("descricao", descricao);
    localStorage.setItem("especie", especie);
    localStorage.setItem("numero_animais", numero_animais);
    localStorage.setItem("descricao_animal", descricao_animal);
    localStorage.setItem("informacoes_relevantes", informacoes_relevantes);
    // Habilita o link para permitir o redirecionamento
    return true;
  }
}
