document.addEventListener("DOMContentLoaded", function () {
  // Recupere os valores do Local Storage
  let nome = localStorage.getItem("nome");
  let email = localStorage.getItem("email");
  let cpf = localStorage.getItem("cpf");
  let telefone = localStorage.getItem("telefone");
  let localizacao = localStorage.getItem("localizacao");

  let data = localStorage.getItem("data");
  let descricao = localStorage.getItem("descricao");
  let consequencias = localStorage.getItem("consequencias");
  let observacoesFinais = localStorage.getItem("observacoesFinais");

  // Preencha os campos do relatório com os valores recuperados
  if (nome != "") {
    document.getElementById("nome").textContent = nome;
  } else {
    document.getElementById("nome").textContent = "N/A";
  }
  if (email != "") {
    document.getElementById("email").textContent = email;
  } else {
    document.getElementById("email").textContent = "N/A";
  }
  if (cpf != "") {
    document.getElementById("cpf").textContent = cpf;
  } else {
    document.getElementById("cpf").textContent = "N/A";
  }
  if (telefone != "") {
    document.getElementById("telefone").textContent = telefone;
  } else {
    document.getElementById("telefone").textContent = "N/A";
  }
  if (localizacao != "") {
    document.getElementById("localizacao").textContent = localizacao;
  } else {
    document.getElementById("localizacao").textContent = "N/A";
  }
  if (data != "") {
    document.getElementById("data").textContent = data;
  } else {
    document.getElementById("data").textContent = "N/A";
  }
  if (descricao != "") {
    document.getElementById("descricao").textContent = descricao;
  } else {
    document.getElementById("descricao").textContent = "N/A";
  }
  if (consequencias != "") {
    document.getElementById("consequencias").textContent = consequencias;
  } else {
    document.getElementById("consequencias").textContent = "N/A";
  }

  if (observacoesFinais != "") {
    document.getElementById("observacoesFinais").textContent =
      observacoesFinais;
  } else {
    document.getElementById("observacoesFinais").textContent = "N/A";
  }
});

function validarFormulario() {
  const formulario = document.getElementById("meuFormulario");
  const checkbox = document.getElementById("declaracao");
  const submitBtn = document.getElementById("submitBtn");

  submitBtn.addEventListener("click", function () {
    if (!checkbox.checked) {
      alert("Clique na caixa de seleção para declarar as informações.");
    } else {
      alert(
        "Parabéns! Você declarou as informações, mas nada foi enviado pois não temos banco :("
      );
    }
  });
}

document.addEventListener("DOMContentLoaded", validarFormulario);
