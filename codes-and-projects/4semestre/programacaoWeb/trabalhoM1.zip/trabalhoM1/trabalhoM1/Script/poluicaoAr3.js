document.addEventListener("DOMContentLoaded", function () {
  // Recupere os valores do Local Storage
  let nome = localStorage.getItem("nome");
  let email = localStorage.getItem("email");
  let telefone = localStorage.getItem("telefone");
  let local = localStorage.getItem("local");
  let data = localStorage.getItem("data");
  let descricao = localStorage.getItem("descricao");
  let impacto_ambiental = localStorage.getItem("impacto_ambiental");
  let testemunha = localStorage.getItem("testemunha");

  // Preencha os campos do relatório com os valores recuperados
  if (nome != "") {
    document.getElementById("nome").textContent = nome;
  } else {
    document.getElementById("nome").textContent = "N/A";
  }
  if (email != "") {
    document.getElementById("email").textContent = email;
  } else {
    document.getElementById("email").textContent = "N/A";
  }
  if (telefone != "") {
    document.getElementById("telefone").textContent = telefone;
  } else {
    document.getElementById("telefone").textContent = "N/A";
  }
  if (local != "") {
    document.getElementById("local").textContent = local;
  } else {
    document.getElementById("local").textContent = "N/A";
  }
  if (data != "") {
    document.getElementById("data").textContent = data;
  } else {
    document.getElementById("data").textContent = "N/A";
  }
  if (descricao != "") {
    document.getElementById("descricao").textContent = descricao;
  } else {
    document.getElementById("descricao").textContent = "N/A";
  }
  if (impacto_ambiental != "") {
    document.getElementById("impacto_ambiental").textContent =
      impacto_ambiental;
  } else {
    document.getElementById("impacto_ambiental").textContent = "N/A";
  }
  if (testemunha != "") {
    document.getElementById("testemunha").textContent = testemunha;
  } else {
    document.getElementById("testemunha").textContent = "N/A";
  }
});

function validarFormulario() {
  const formulario = document.getElementById("meuFormulario");
  const checkbox = document.getElementById("declaracao");
  const submitBtn = document.getElementById("submitBtn");

  submitBtn.addEventListener("click", function () {
    if (!checkbox.checked) {
      alert("Clique na caixa de seleção para declarar as informações.");
    } else {
      alert(
        "Parabéns! Você declarou as informações, mas nada foi enviado pois não temos banco :("
      );
    }
  });
}

document.addEventListener("DOMContentLoaded", validarFormulario);
