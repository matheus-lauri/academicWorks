function proximaPagina(event) {
  // Coleta os valores dos inputs
  let nome = document.getElementById("nome").value;
  let email = document.getElementById("email").value;
  let cpf = document.getElementById("cpf").value;
  let telefone = document.getElementById("telefone").value;
  let localizacao = document.getElementById("localizacao").value;

  // Verifica se os campos required estão vazios
  if (!nome || !email || !cpf || !telefone || !localizacao) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Salva os valores no Local Storage
    localStorage.setItem("nome", nome);
    localStorage.setItem("email", email);
    localStorage.setItem("cpf", cpf);
    localStorage.setItem("telefone", telefone);
    localStorage.setItem("localizacao", localizacao);
    return true;
  }
}
