function proximaPagina(event) {
  // Coleta os valores dos inputs
  let data = document.getElementById("data").value;
  let descricao = document.getElementById("descricao").value;
  let consequencias = document.getElementById("consequencias").value;

  // Verifica se os campos required estão vazios
  if (!data || !descricao || !consequencias) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Obtenha o valor do campo opcional
    let observacoesFinais = document.getElementById("observacoesFinais").value;
    // Salva os valores no Local Storage
    localStorage.setItem("data", data);
    localStorage.setItem("descricao", descricao);
    localStorage.setItem("consequencias", consequencias);
    localStorage.setItem("observacoesFinais", observacoesFinais);
    return true;
  }
}
