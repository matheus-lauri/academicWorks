document.addEventListener("DOMContentLoaded", function () {
  // Recupere os valores do Local Storage
  let nome = localStorage.getItem("nome");
  let email = localStorage.getItem("email");
  let local = localStorage.getItem("local");
  let descricao = localStorage.getItem("descricao");
  let data = localStorage.getItem("data");
  let tipo_poluicao = localStorage.getItem("tipo_poluicao");
  let gravidade = localStorage.getItem("gravidade");

  if (tipo_poluicao == "poluicao_biologica") {
    tipo_poluicao = "Biológica";
  } else if (tipo_poluicao == "poluicao_quimica") {
    tipo_poluicao = "Química";
  } else if (tipo_poluicao == "poluicao_termica") {
    tipo_poluicao = "Térmica";
  } else {
    tipo_poluicao = "N/A";
  }

  let observacoesAmais = localStorage.getItem("observacoesAmais");
  // Preencha os campos do relatório com os valores recuperados
  if (nome != "") {
    document.getElementById("nome").textContent = nome;
  } else {
    document.getElementById("nome").textContent = "N/A";
  }
  if (data != "") {
    document.getElementById("data").textContent = data;
  } else {
    document.getElementById("data").textContent = "N/A";
  }
  if (tipo_poluicao != "") {
    document.getElementById("tipo_poluicao").textContent = tipo_poluicao;
  } else {
    document.getElementById("tipo_poluicao").textContent = "N/A";
  }
  if (email != "") {
    document.getElementById("email").textContent = email;
  } else {
    document.getElementById("email").textContent = "N/A";
  }
  if (local != "") {
    document.getElementById("local").textContent = local;
  } else {
    document.getElementById("local").textContent = "N/A";
  }

  if (gravidade != "") {
    document.getElementById("gravidade").textContent = gravidade;
  } else {
    document.getElementById("gravidade").textContent = "N/A";
  }
  if (descricao != "") {
    document.getElementById("descricao").textContent = descricao;
  } else {
    document.getElementById("descricao").textContent = "N/A";
  }
  if (observacoesAmais != "") {
    document.getElementById("observacoesAmais").textContent = observacoesAmais;
  } else {
    document.getElementById("observacoesAmais").textContent = "N/A";
  }
});

function validarFormulario() {
  const formulario = document.getElementById("meuFormulario");
  const checkbox = document.getElementById("declaracao");
  const submitBtn = document.getElementById("submitBtn");

  submitBtn.addEventListener("click", function () {
    if (!checkbox.checked) {
      alert("Clique na caixa de seleção para declarar as informações.");
    } else {
      alert(
        "Parabéns! Você declarou as informações, mas nada foi enviado pois não temos banco :("
      );
    }
  });
}

document.addEventListener("DOMContentLoaded", validarFormulario);
