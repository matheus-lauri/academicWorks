function avancarPagina(event) {
  let data = document.getElementById("data").value;
  let tipo_poluicao = document.getElementById("tipo_poluicao");
  let valorTipoPoluicao = tipo_poluicao.value;
  let gravidades = document.getElementsByName("gravidade");
  let opcaoSelecionada;
  for (const gravidade of gravidades) {
    if (gravidade.checked) {
      opcaoSelecionada = gravidade.value;
      break;
    }
  }
  let observacoesAmais = document.getElementById("observacoesAmais").value;

  // Verifica se os campos required estão vazios
  if (!data || !tipo_poluicao || !opcaoSelecionada) {
    // Impede o redirecionamento se algum campo não estiver preenchido
    event.preventDefault();
    alert("Por favor, preencha todos os campos obrigatórios.");
  } else {
    // Salvar dados no Local Storage
    localStorage.setItem("data", data);
    localStorage.setItem("tipo_poluicao", valorTipoPoluicao);
    localStorage.setItem("gravidade", opcaoSelecionada);
    localStorage.setItem("observacoesAmais", observacoesAmais);
    return true;
  }
}
