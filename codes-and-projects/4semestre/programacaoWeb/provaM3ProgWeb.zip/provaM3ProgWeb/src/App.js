import "./style.css";
import Menu from "./Components/Menu/Menu";
import Header from "./Components/Header/Header";
import Footer from "./Components/Footer/Footer";
import CardPost from "./Components/CardPost/CardPost";

export default function App() {
  return (
    <div className="App">
      <Menu />
      <Header />
      <CardPost
        titulo="Beautiful London"
        urlImage="https://images.pexels.com/photos/1796715/pexels-photo-1796715.jpeg?cs=srgb&dl=pexels-chait-goli-1796715.jpg&fm=jpg"
        autor="Gustavo"
        data="08/12/2023"
        texto="Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
        doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis 
        et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem 
        quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores 
        eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum 
        quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi 
        tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad 
        minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi 
        ut aliquid ex ea commodi consequatur?"
      />
      <CardPost
        titulo="Pretty Hong Kong"
        urlImage="https://www.infoescola.com/wp-content/uploads/2020/08/hong-kong_693729124.jpg"
        autor="Matheus"
        data="07/12/2023"
        texto="Duis nibh mi, accumsan quis tristique sit amet, cursus quis dolor. Suspendisse potenti. Proin eleifend quam at tellus pretium euismod. Quisque imperdiet, sapien ut elementum dignissim, nibh nibh convallis augue, consequat varius felis dui ut nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent et purus neque. Morbi metus tellus, porta nec faucibus vel, pharetra id ligula. Praesent sodales ac orci et pellentesque. Nulla nec ante porttitor, semper libero vitae, fermentum turpis. Donec auctor erat in purus convallis dictum. Fusce felis enim, lacinia venenatis nunc id, faucibus pulvinar lectus. Aliquam sed magna vitae justo sollicitudin varius."
      />
      <CardPost
        titulo="Awesome New York"
        urlImage="https://www.remessaonline.com.br/blog/wp-content/uploads/2022/06/morar-em-nova-york-1170x777.jpg.webp"
        autor="Maria"
        data="06/12/2023"
        texto="Quisque semper eget turpis eget iaculis. Integer aliquet maximus lectus vel vestibulum. Etiam cursus dolor molestie diam hendrerit, ut semper purus eleifend. Sed lacinia faucibus facilisis. Ut orci nunc, iaculis vel facilisis sed, fringilla id odio. Phasellus ipsum risus, tristique non elementum at, efficitur ut lacus. Proin auctor ut nibh in facilisis. Aenean in interdum urna, vel sodales sapien. Etiam sodales metus ac est dapibus iaculis. Fusce vulputate volutpat purus, vel consectetur urna vestibulum nec. Aliquam a felis vehicula diam mattis efficitur vitae id lacus. Vestibulum eget dictum elit. In pellentesque, lectus non efficitur dignissim, mi lectus ornare magna, consectetur tincidunt nunc urna nec erat. Ut odio massa, tincidunt eu fringilla at, ullamcorper vitae eros. Cras dolor ligula, eleifend vitae ex facilisis, rutrum porttitor urna."
      />
      <CardPost
        titulo="Amazing Sydney"
        urlImage="https://upload.wikimedia.org/wikipedia/commons/8/8a/Sydney_Opera_House_from_the_east.jpg"
        autor="Ana"
        data="05/12/2023"
        texto="Praesent nunc quam, maximus in pellentesque nec, tincidunt sodales est. Aliquam arcu lorem, tempor sit amet est et, bibendum lacinia ex. Nulla mi nibh, suscipit at luctus eget, rhoncus sit amet ante. Proin sed orci vitae tellus faucibus porttitor. Fusce porttitor eleifend justo et posuere. In hac habitasse platea dictumst. Phasellus a vulputate nibh, ut viverra velit. Nulla facilisi. Cras malesuada rutrum mi nec malesuada. Praesent et feugiat est, non viverra quam. Quisque ac velit sodales, faucibus turpis vitae, eleifend lectus. Suspendisse dolor velit, ullamcorper et dignissim id, rhoncus lobortis ipsum."
      />
      <Footer />
    </div>
  );
}
