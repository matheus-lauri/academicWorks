import "./CardPost.css";
import Comment from "../Comment/Comment";
import WriteComment from "../WriteComment/WriteComment";

function CardPost(props) {
  return (
    <div className="CardPost">
      <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
          <div class="col-md-10 col-lg-8 col-xl-7">
            <div class="blog-post">
              <h2 class="blog-post-title">{props.titulo}</h2>
              <img
                src={props.urlImage}
                class="img-fluid"
                alt="Responsive image"
              />
              <p class="blog-post-meta">
                {props.data} by <a href="#">{props.autor}</a>
              </p>
              <p>{props.texto}</p>
              <h3>Comments:</h3>
              <Comment
                urlIcone="https://i.imgur.com/RpzrMR2.jpg"
                nome="Yasmin"
                data="08/12/2023"
                comentario="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do 
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim 
                veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea 
                commodo consequat."
              />
              <Comment
                urlIcone="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                nome="Pedro"
                data="07/12/2023"
                comentario="Sed ut perspiciatis unde omnis iste natus error sit voluptatem 
                accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab 
                illo inventore veritatis et quasi architecto beatae vitae dicta sunt 
                explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut 
                odit aut fugit."
              />
              <WriteComment urlIcone="https://i.imgur.com/RpzrMR2.jpg" />
            </div>

            <hr class="my-4" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default CardPost;
