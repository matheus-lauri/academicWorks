import "./WriteComment.css";

function WriteComment(props) {
  return (
    <div className="WriteComment">
      <div class="bg-light p-2">
        <div class="d-flex flex-row align-items-start">
          <img
            class="rounded-circle"
            src={props.urlIcone}
            width="60"
            height="60"
          />
          <textarea class="form-control ml-1 shadow-none textarea"></textarea>
        </div>
        <div class="mt-2 text-right">
          <button class="btn btn-primary btn-sm shadow-none" type="button">
            Post comment
          </button>
          <button
            class="btn btn-outline-primary btn-sm ml-1 shadow-none"
            type="button"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default WriteComment;
