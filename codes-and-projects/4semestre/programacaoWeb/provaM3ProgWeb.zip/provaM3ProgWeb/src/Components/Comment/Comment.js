import "./Comment.css";

function Comment(props) {
  return (
    <div className="Comment">
      <div class="d-flex flex-column comment-section">
        <div class="bg-white p-2">
          <div class="d-flex flex-row user-info">
            <img
              class="rounded-circle"
              src={props.urlIcone}
              width="60"
              height="60"
            />
            <div class="d-flex flex-column justify-content-start ml-2">
              <span class="d-block font-weight-bold name">{props.nome}</span>
              <span class="date text-black-50">
                Shared publicly - {props.data}
              </span>
            </div>
          </div>
          <div class="mt-2">
            <p class="comment-text">{props.comentario}</p>
          </div>
        </div>
        <div class="bg-white">
          <div class="d-flex flex-row fs-12">
            <div class="like p-2 cursor">
              <i class="fa fa-thumbs-o-up"></i>
              <span class="ml-1">Like</span>
            </div>
            <div class="like p-2 cursor">
              <i class="fa fa-commenting-o"></i>
              <span class="ml-1">Comment</span>
            </div>
            <div class="like p-2 cursor">
              <i class="fa fa-share"></i>
              <span class="ml-1">Share</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Comment;
