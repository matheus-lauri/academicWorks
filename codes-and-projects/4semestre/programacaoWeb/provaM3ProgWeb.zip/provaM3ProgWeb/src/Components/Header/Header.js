import "./Header.css";

function Header() {
  return (
    <section className="header">
      <header class="masthead" id="headImg">
        <div class="container position-relative px-4 px-lg-5">
          <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
              <div class="site-heading">
                <h1>Travel Blog</h1>
                <span class="subheading">
                  A blog to help you with your travel!
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>
    </section>
  );
}
export default Header;
