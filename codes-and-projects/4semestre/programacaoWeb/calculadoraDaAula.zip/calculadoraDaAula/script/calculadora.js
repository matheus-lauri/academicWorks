function setDisplay(x) {
  var display = document.getElementById("display");
  display.value += x;
}
function setResultado() {
  var res = document.getElementById("display").value;
  res = eval(res);
  document.getElementById("display").value = res;
}
function Clean() {
  document.getElementById("display").value = "";
}
