import "./AdicionarLivro.css";
import Botao from "../Botao/Botao";
import Campo from "../Campo/Campo";
import AreaTexto from "../AreaTexto/AreaTexto";
import { useState } from "react";

function AdicionarLivro(props) {
  const [titulo, setTitulo] = useState("");
  const [resumo, setResumo] = useState("");
  const [editora, setEditora] = useState("");
  const [autores, setAutores] = useState("");

  const aoSalvar = (evento) => {
    alert("Form foi submetido!");
    evento.preventDefault();
    props.aoLivroCadastrado({
      titulo,
      resumo,
      editora,
      autores,
    });
  };

  return (
    <section className="cadastro">
      <form onSubmit={aoSalvar}>
        <h2> Preencha os campos com as informações dos livros </h2>
        <Campo
          obrigatorio="true"
          label="Título"
          placeholder="Insira o título..."
          valor={titulo}
          aoAlterar={(valor) => setTitulo(valor)}
        />
        <AreaTexto
          obrigatorio="true"
          label="Resumo"
          placeholder="Descreva o resumo..."
          valor={resumo}
          aoAlterar={(valor) => setResumo(valor)}
        />
        <Campo
          obrigatorio="true"
          label="Editora"
          placeholder="Insira o nome da editora..."
          valor={editora}
          aoAlterar={(valor) => setEditora(valor)}
        />
        <AreaTexto
          obrigatorio="true"
          label="Autores"
          placeholder="Liste os autores..."
          valor={autores}
          aoAlterar={(valor) => setAutores(valor)}
        />
        <Botao texto="Adicionar Livro" />
      </form>
    </section>
  );
}

export default AdicionarLivro;
