import "./ListaCategorias.css";

function ListaCategorias(props) {
  return (
    <ul className="listaCategorias">
      <li>
        <a href="#">{props.item1}</a>
      </li>
      <li>
        <a href="#">{props.item2}</a>
      </li>
      <li>
        <a href="#">{props.item3}</a>
      </li>
      <li>
        <a href="#">{props.item4}</a>
      </li>
    </ul>
  );
}

export default ListaCategorias;
