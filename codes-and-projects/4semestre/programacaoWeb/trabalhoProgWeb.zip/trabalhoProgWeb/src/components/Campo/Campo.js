import "./Campo.css";

function Campo(props) {
  //const [valor, setValor] = useState("");

  const aoDigitar = (evento) => {
    props.aoAlterar(evento.target.value);
    console.log(evento.target.value);
  };

  return (
    <div className="campo">
      <label> {props.label} </label>
      <input
        value={props.valor}
        onChange={aoDigitar}
        required={props.obrigatorio}
        placeholder={props.placeholder}
      />
    </div>
  );
}

export default Campo;
