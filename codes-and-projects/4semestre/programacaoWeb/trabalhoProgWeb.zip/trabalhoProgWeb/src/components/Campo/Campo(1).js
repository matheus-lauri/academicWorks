import "./Campo.css";

function Campo(props) {
  return (
    <div className="campo" id={props.tipo}>
      <label> {props.label} </label>
      <input />
    </div>
  );
}

export default Campo;
