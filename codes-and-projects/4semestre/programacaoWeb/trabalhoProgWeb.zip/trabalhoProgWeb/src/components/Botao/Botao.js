function Botao(props) {
  return <button class="btn btn-success">{props.texto}</button>;
}

export default Botao;
