import "./AreaTexto.css";

function AreaTexto(props) {
  //const [valor, setValor] = useState("");

  const aoDigitar = (evento) => {
    props.aoAlterar(evento.target.value);
    console.log(evento.target.value);
  };

  return (
    <div className="areaTexto">
      <label> {props.label} </label>
      <textarea
        value={props.valor}
        onChange={aoDigitar}
        required={props.obrigatorio}
        placeholder={props.placeholder}
      />
    </div>
  );
}

export default AreaTexto;
