import "./Tabela.css";

function Tabela(props) {
  const onDeleteLivro = (index) => {
    const newArray = [...props.livros];
    newArray.splice(index, 1);
    props.setLivros(newArray);
  };

  return (
    <section className="tabela">
      <table class="table table-striped">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Título</th>
            <th scope="col">Resumo</th>
            <th scope="col">Editora</th>
            <th scope="col">Autores</th>
            <th scope="col">Ação</th>
          </tr>
        </thead>
        {props.livros.map((livro, index) => (
          <tbody>
            <tr key={index}>
              <td>{livro.titulo}</td>
              <td>{livro.resumo}</td>
              <td>{livro.editora}</td>
              <td>{livro.autores}</td>
              <td>
                <button
                  type="button"
                  class="btn btn-danger"
                  onClick={() => onDeleteLivro(index)}
                >
                  Excluir
                </button>
              </td>
            </tr>
          </tbody>
        ))}
      </table>
    </section>
  );
}

export default Tabela;
