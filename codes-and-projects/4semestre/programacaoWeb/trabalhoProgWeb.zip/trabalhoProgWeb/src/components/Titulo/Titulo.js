import "./Titulo.css";

function Titulo(props) {
  return (
    <section className="titulo">
      <h1>{props.value}</h1>
    </section>
  );
}

export default Titulo;
