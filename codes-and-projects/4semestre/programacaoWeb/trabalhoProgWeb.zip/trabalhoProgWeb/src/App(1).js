import Header from "./Components/Header/Header";
import Footer from "./Components/Footer/Footer";
import FormularioDireita from "./Components/FormularioDireita/FormularioDireita";
import FormularioEsquerda from "./Components/FormularioEsquerda/FormularioEsquerda";
import "./app.css";

export default function App() {
  return (
    <div className="App">
      <Header />
      <div className="container">
        <FormularioEsquerda />

        <FormularioDireita />
      </div>
      <Footer />
    </div>
  );
}
