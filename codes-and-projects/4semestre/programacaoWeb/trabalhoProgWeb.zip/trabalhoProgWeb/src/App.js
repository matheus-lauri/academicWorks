import "./styles.css";
import Tabela from "./components/Tabela/Tabela";
import Titulo from "./components/Titulo/Titulo";
import Formulario from "./components/AdicionarLivro/AdicionarLivro";
import { useState } from "react";

export default function App() {
  const [livros, setLivros] = useState([]);

  const aoAdicionarLivro = (livro) => {
    console.log(livro);
    setLivros([...livros, livro]);
  };

  return (
    <div className="App">
      <Titulo value="Catálogo de Livros" />
      <Tabela livros={livros} setLivros={setLivros} />
      <Formulario aoLivroCadastrado={(livro) => aoAdicionarLivro(livro)} />
    </div>
  );
}
