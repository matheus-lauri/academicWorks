<?php

require 'Conexao.php';

class Jogador
{

    private $conexao;

    public function __construct()
    {
        $con = new Conexao();
        $this->conexao = $con->getConexao();
    }

    public function pesquisar($inicio, $limite, $pesquisa)
    {
        // Adiciona curingas à variável de pesquisa para usar com LIKE
        $pesquisa = "%{$pesquisa}%";

        // Prepara a instrução SQL usando uma instrução preparada
        $sql = "SELECT idJogador, nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, equipe.nomeEquipe FROM jogador JOIN equipe ON jogador.FK_idEquipe = equipe.idEquipe WHERE 
        statusJogador = 1
        AND (nomeJogador LIKE ? 
        OR dataNascimentoJogador LIKE ?
        OR posicaoJogador LIKE ?
        OR alturaJogador LIKE ?
        OR pesoJogador LIKE ?
        OR equipe.nomeEquipe LIKE ?) 
        ORDER BY idJogador LIMIT ?, ?";
        $q = $this->conexao->prepare($sql);

        // Verifica se a preparação foi bem-sucedida
        if (!$q) {
            die('Erro na preparação da consulta: ' . $this->conexao->errorInfo());
        }

        // Liga os parâmetros
        $q->bindParam(1, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(2, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(3, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(4, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(5, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(6, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(7, $inicio, PDO::PARAM_INT);
        $q->bindParam(8, $limite, PDO::PARAM_INT);

        // Executa a consulta
        $q->execute();

        // Retorna o resultado
        return $q;
    }

    public function contarPesquisa($pesquisa)
    {

        // Adiciona curingas à variável de pesquisa para usar com LIKE
        $pesquisa = "%{$pesquisa}%";

        $sql = "SELECT COUNT(idJogador) count FROM jogador JOIN equipe ON jogador.FK_idEquipe = equipe.idEquipe WHERE 
        statusJogador = 1
        AND (nomeJogador LIKE ? 
        OR dataNascimentoJogador LIKE ?
        OR posicaoJogador LIKE ?
        OR alturaJogador LIKE ?
        OR pesoJogador LIKE ?
        OR equipe.nomeEquipe LIKE ?)";
        $q = $this->conexao->prepare($sql);

        // Verifica se a preparação foi bem-sucedida
        if (!$q) {
            die('Erro na preparação da consulta: ' . $this->conexao->errorInfo());
        }

        // Liga os parâmetros
        $q->bindParam(1, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(2, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(3, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(4, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(5, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(6, $pesquisa, PDO::PARAM_STR);

        $q->execute();
        return $q;
    }

    public function listar($inicio, $limite)
    {
        $sql = "SELECT idJogador, nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, equipe.nomeEquipe FROM jogador JOIN equipe ON jogador.FK_idEquipe = equipe.idEquipe WHERE statusJogador = 1 ORDER BY idJogador LIMIT ?, ?;";
        $q = $this->conexao->prepare($sql);


        $q->bindParam(1, $inicio, PDO::PARAM_INT);
        $q->bindParam(2, $limite, PDO::PARAM_INT);
        $q->execute();
        return $q;
    }

    public function contar()
    {
        $sql = "SELECT COUNT(nomeJogador) count FROM jogador WHERE statusJogador = 1;";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;
    }

    # idJogador, nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, statusJogador, FK_idEquipe
    public function inserir($nomeJogador, $dataNascimentoJogador, $posicaoJogador, $alturaJogador, $pesoJogador, $FK_idEquipe)
    {

        $sql = 'INSERT INTO jogador ( nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, statusJogador, FK_idEquipe) VALUES (?, ?, ?, ?, ?, 1, ?)';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeJogador);
        $q->bindParam(2, $dataNascimentoJogador);
        $q->bindParam(3, $posicaoJogador);
        $q->bindParam(4, $alturaJogador);
        $q->bindParam(5, $pesoJogador);
        $q->bindParam(6, $FK_idEquipe);

        $q->execute();
    }

    public function getJogador($idJogador)
    {

        $sql = 'SELECT * FROM jogador WHERE idJogador = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idJogador);

        $q->execute();

        $jogador = [];

        foreach ($q as $a) {
            $jogador = $a;
        }

        return $jogador;
    }

    public function editar($idJogador, $nomeJogador, $dataNascimentoJogador, $posicaoJogador, $alturaJogador, $pesoJogador, $FK_idEquipe)
    {

        $sql = 'UPDATE jogador SET nomeJogador = ?, dataNascimentoJogador = ?, posicaoJogador = ?, alturaJogador = ?, pesoJogador = ?, FK_idEquipe = ? WHERE idJogador = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeJogador);
        $q->bindParam(2, $dataNascimentoJogador);
        $q->bindParam(3, $posicaoJogador);
        $q->bindParam(4, $alturaJogador);
        $q->bindParam(5, $pesoJogador);
        $q->bindParam(6, $FK_idEquipe);
        $q->bindParam(7, $idJogador);

        $q->execute();
    }

    public function eliminar($idJogador)
    {

        $sql = "UPDATE jogador SET statusJogador = 0 WHERE idJogador = ? ";

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idJogador);

        $q->execute();
    }

    //funcao auxiliar com query em outra tabela
    public function mostrarNomesEquipes()
    {
        $sql = "SELECT idEquipe, nomeEquipe FROM equipe;";

        $q = $this->conexao->prepare($sql);

        $q->execute();
        return $q;
    }
}
