<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editar Jogador</title>

  <!-- Font Awesome icons-->
  <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
  <!-- Google fonts-->
  <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />

  <link rel="icon" type="image/x-icon" href="../assets/icon_basquete.png" />

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

  <link href="../style/styles.css" rel="stylesheet" />

</head>

<body>

  <?php

  require '../Classes/Jogador.php';
  $jog = new Jogador();

  //Lista de nomes das equipes

  $listaNomesEquipes = $jog->mostrarNomesEquipes();

  //Edicao

  $redirecionar = true;

  if (isset($_GET['idJogador'])) {
    if (is_numeric($_GET['idJogador'])) {

      $redirecionar = false;

      if (isset($_POST['nomeJogador'])) {

        $jog->editar($_GET['idJogador'], $_POST['nomeJogador'], $_POST['dataNascimentoJogador'], $_POST['posicaoJogador'], $_POST['alturaJogador'], $_POST['pesoJogador'], $_POST['FK_idEquipe']);
      }

      $jogador = $jog->getJogador($_GET['idJogador']);
    }
  }

  if ($redirecionar) {
    header("Location: index.php");
    exit();
  }

  ?>

  <?php if (isset($_POST['nomeJogador'])) { ?>
    <script>
      alert('Jogador atualizado com sucesso!');
    </script>
  <?php } ?>

  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg bg-dark fixed-top" id="mainNav">
    <div class="container px-4 px-lg-5">
      <a class="navbar-brand" href="../index.php"><img src="../assets/icon_basquete.png" alt="..." style="width: 80px;height: 80px;"> Início</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <div class="container">
              <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                  <a class="navbar-brand" href="../jogador.php">Jogador</a>
                </div>
              </nav>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="masthead">
    <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
      <div class="d-flex justify-content-center">
        <div class="text-center">
          <center>
            <form action="editar_jogador.php?idJogador=<?php echo $_GET['idJogador']; ?>" method="post">
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="nome" class="form-label" style="text-align: inherit;color:#fff">Nome:</label>
                <input type="text" value="<?php echo $jogador['nomeJogador']; ?>" class="form-control" id="nomeJogador" name="nomeJogador" required>
              </div>
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="dataNascimentoJogador" class="form-label" style="color: #fff;">Data de Nascimento:</label>
                <input type="date" value="<?php echo $jogador['dataNascimentoJogador']; ?>" class="form-control" id="dataNascimentoJogador" name="dataNascimentoJogador" required>
              </div>
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="posicaoJogador" class="form-label" style="color: #fff;">Posição:</label>
                <input type="double" value="<?php echo $jogador['posicaoJogador']; ?>" class="form-control" id="posicaoJogador" name="posicaoJogador" required>
              </div>
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="alturaJogador" class="form-label" style="color: #fff;">Altura:</label>
                <input type="double" value="<?php echo $jogador['alturaJogador']; ?>" class="form-control" id="alturaJogador" name="alturaJogador" required>
              </div>
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="pesoJogador" class="form-label" style="color: #fff;">Peso:</label>
                <input type="double" value="<?php echo $jogador['pesoJogador']; ?>" class="form-control" id="pesoJogador" name="pesoJogador" required>
              </div>
              <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
                <label for="FK_idEquipe" class="form-label" style="color: #fff;">Selecione uma Equipe:</label>
                <select name="FK_idEquipe" id="FK_idEquipe" class="form-select">
                  <?php foreach ($listaNomesEquipes as $e) { ?>
                    <option value="<?php echo $e['idEquipe']; ?>"><?php echo $e['nomeEquipe']; ?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="row">
                <div class="col-12 col-md-12">
                  <button class="btn btn-outline-primary" type="submit">Salvar</button>
                </div>
              </div>
              <br />
              <div class="col-12 col-md-12">
                <a class="btn btn-outline-light" href="../index.php"><i class="fas fa-arrow-alt-circle-left"></i> Voltar o início</a>
                <a class="btn btn-outline-light" href="../jogador.php"><i class="fas fa-arrow-alt-circle-left"></i> Voltar a lista de jogadores</a>
              </div>
            </form>
          </center>
        </div>
      </div>
    </div>
  </header>

  <div class="d-flex justify-content-center" style="background-color: #212529;font-size: 20px;">
    <div class="text-center">
      <!-- Footer-->
      <footer class="footer small text-center text-white-50">
        <div class="container px-4 px-lg-5">Copyright &copy; Desenvolvido por Gustavo Baron Lauritzen, Matheus Baron Lauritzen e Gabriel Bósio 2023</div>
      </footer>
    </div>
  </div>

  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="js/scripts.js"></script>
  <!-- SB Forms JS -->
  <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
</body>

</html>