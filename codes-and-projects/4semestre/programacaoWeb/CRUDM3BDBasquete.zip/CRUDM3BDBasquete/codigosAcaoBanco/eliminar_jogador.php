<?php

require '../classes/Jogador.php';

if (isset($_GET['idJogador'])) {

  if (is_numeric($_GET['idJogador'])) {

    $jogador = new Jogador();
    $jogador->eliminar($_GET['idJogador']);
  }
}

header("Location: ../jogador.php");
exit();
