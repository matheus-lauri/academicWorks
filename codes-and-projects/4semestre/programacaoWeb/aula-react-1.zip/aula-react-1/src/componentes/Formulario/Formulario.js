import "./Formulario.css";
import CampoTexto from "../CampoTexto/CampoTexto";
import Lista from "../Lista/Lista";

const time = ["Programação", "Front-End", "Data Science", "AI", "Mobile"];

function Formulario() {
  return (
    <section className="formulario">
      <form>
        <h2> Preencha os dados para criar uma conta </h2>
        <CampoTexto label="Nome" placeholder="Digite seu nome" />
        <CampoTexto label="Cargo" placeholder="Digite seu cargo" />
        <CampoTexto label="Imagem" placeholder="Digite o endereço da imagem" />
        <Lista label="Time" itens={time} />
      </form>
    </section>
  );
}
export default Formulario;
