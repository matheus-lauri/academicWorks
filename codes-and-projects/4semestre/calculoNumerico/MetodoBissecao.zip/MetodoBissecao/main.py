import math
import sympy
import numpy as np

# Definindo a funcao
def f(x):
    return np.power(x,78) - 7853653

# Definindo os intervalos[a, b]
a = 1
b = 2

# Teorema de Bolzano
if f(a) * f(b) < 0:
    i = 1
    # Mudar o numero de iteracoes(i) de acordo com o erro
    while (i<10):
        xi = (a + b) / 2
        if f(xi) == 0:
            print("A raiz final é: ", xi)
            break
        else:
            if f(a) * f(xi) < 0:
                print("iteração: ", i, " | a: ", a, " | raiz: ", xi," | b: ", b, " | f(a): ", f(a), " | f(x): ", f(xi), " | f(b): ", f(b), " | Erro: (b-a)/2", math.fabs(b-a) / 2)
                b = xi;
                i = i + 1
            else:
                print("iteração: ", i, " | a: ", a, " | raiz: ", xi," | b: ", b, " | f(a): ", f(a), " | f(x): ", f(xi), " | f(b): ", f(b), " | Erro: (b-a)/2", math.fabs(b-a) / 2)
                a = xi;
                i = i + 1
    print("O valor da raiz final é: ", xi)

else:
    print("Não podemos garantir que há raiz no intervalo")



