import math
#Desenvolvido por Matheus Baron Lauritzen e Gustavo Baron Lauritzen
#Funcao para comparar se chegou no criterio de parada do erro estabelecido
def comparar(x, xk, eps):
    soma = 0
    zip_object = zip(x, xk)
    for list1_i, list2_i in zip_object:
        soma = soma + math.fabs(list1_i - list2_i)
    print("x1 = ", xk[0],"x2 = ",xk[1],"x3 = ",xk[2])
    print("Erro absoluto(x1):", abs(math.fabs(xk[0]-x[0])),"Erro absoluto(x2):", abs(math.fabs(xk[1]-x[1])),"Erro absoluto(x3):", abs(math.fabs(xk[2]-x[2])))
    print("Erro relativo(x1): ",abs((math.fabs(xk[0]-x[0])/xk[0])*100),"%"," Erro relativo(x2): ",abs((math.fabs(xk[1]-x[1])/xk[1])*100),"%"," Erro relativo(x3): ",abs((math.fabs(xk[2]-x[2])/xk[2])*100),"%",sep="")
    if (soma < eps):
        return True
    else:
        return False
#Funcao do metodo de Gauss Seidel
def gaussSeidel(A, b, maxiter, erro):
    n = len(b)
    sol = True
    x = b.copy()
    #Verificando se o sistema admite solucao unica
    for i in list(range(1, n + 1, 1)):
        if (math.fabs(A[i - 1][i - 1]) > 0.0):
            x[i - 1] = b[i - 1] / A[i - 1][i - 1]
        else:
            sol = False
            break
    #Condicao para realizar o metodo de Gauss Seidel caso admita solucao unica
    if (sol):
        #Valores iniciais para x
        x = [7,8,5]
        print("Iteração 0")
        print("x = ", x)
        xk = x.copy()
        iter = 0
        #Percorrendo o sistema e calculando o metodo para cada iteracao
        while (iter < maxiter):
            iter = iter + 1
            for i in list(range(1, n + 1, 1)):
                s = 0
                for j in list(range(1, n + 1, 1)):
                    if ((i - 1) > (j - 1)):
                        s = s + A[i - 1][j - 1] * xk[j - 1]
                    elif ((i - 1) < (j - 1)):
                        s = s + A[i - 1][j - 1] * x[j - 1]

                xk[i - 1] = (1 / A[i - 1][i - 1]) * (b[i - 1] - s)
            print("Iteração ",iter,": ",sep="")
            #Chamada de funcao para comparar se chegou no criterio de parada do erro estabelecido
            if comparar(x, xk, erro):
                x = xk.copy()
                break
            x = xk.copy()
    return x
#Dados iniciais como Matriz A do Sistema, Resultado b do sistema,
# maximo de iteracoes e o criterio de parada do erro
A = [[3, -1, 1],
     [3, 9, 5],
     [3, 3, 7]]
b = [4, 0, 4]
maxiter = 3
erro = 0.0001
#Chamada da funcao do metodo
x = gaussSeidel(A, b, maxiter, erro)
print("Valor final de x = ", x)