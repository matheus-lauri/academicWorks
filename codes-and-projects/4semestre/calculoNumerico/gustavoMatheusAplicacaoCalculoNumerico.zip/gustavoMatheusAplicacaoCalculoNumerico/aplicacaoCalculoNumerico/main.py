#Calculando a integral aproximada pelo metodo de 1/3 de Simpson
arrayY = [29.31, 29.32, 29.4, 29.45, 29.51,
          29.57, 29.62, 29.69, 29.73, 29.77,
          29.83, 29.86, 29.92, 29.97, 30.03,
          30.14, 30.4, 30.39, 30, 28.4, 25.04]
#Limite inferior X
Xa = 1.9
#Limite superior X
Xb = 20.7
#Limite inferior Y
Ya = arrayY[0]
#Limite superior Y
Yb = arrayY[20]
#Quantidade de subintervalos
n = 20
#comprimento dos subintervalos
h = round((Xb-Xa)/n, 2)

i = 1
sum = 0

while(i<n):
    y = arrayY[i]
    if(i%2==0):
        sum = sum + 2*y
    else:
        sum = sum + 4*y
    i = i + 1

Ia = (h/3)*(Ya+Yb+sum)
print("Valor da Integral Aproximada por 1/3 Simpson = ", Ia)
erro = abs(556.91 - Ia)
print("Erro = ", erro)