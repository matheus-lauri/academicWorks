import numpy as np
import math

#Calculando a integral aproximada pela regra de Trapézio
def trapezioR(arrayY):
  # Quantidade de subintervalos
  n = 20
  # Limite inferior X
  Xa = 1.9
  # Limite superior X
  Xb = 20.7
  # Limite inferior Y
  Ya = arrayY[0]
  # Limite superior Y
  Yb = arrayY[20]
  # comprimento dos subintervalos
  h = round((Xb-Xa)/n, 2)
  soma = (Ya+Yb)
  i = 1
  while(i<n):
    soma = soma + 2 * arrayY[i]
    i = i + 1

  Itr = soma*h/2
  return Itr

arrayY = [29.31, 29.32, 29.4, 29.45, 29.51,
          29.57, 29.62, 29.69, 29.73, 29.77,
          29.83, 29.86, 29.92, 29.97, 30.03,
          30.14, 30.4, 30.39, 30, 28.4, 25.04]
Ia = trapezioR(arrayY)
print("Valor da Integral Aproximada pela Regra do Trapezio = ",Ia)
erro = abs(556.91 - Ia)
print("Erro = ", erro)
