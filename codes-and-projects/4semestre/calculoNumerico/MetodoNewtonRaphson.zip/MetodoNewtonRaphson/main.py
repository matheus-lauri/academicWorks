import numpy as np
import math

# Desenvolvido por Matheus Baron Lauritzen e Gustavo Baron Lauritzen

#funcao de f(x), deve modificar e colocar a funcao desejada usada no metodo
def f(x):
  return np.sin(np.sqrt(x)) - x

#funcao de f'(x), deve modificar a partir da f(x) pois essa é a derivada de f(x)
def df(x):
  return (0.5 * (1/np.power(x, 0.5)) * np.cos(np.sqrt(x))) - 1

#dados iniciais
x0 = 0.5 # pode ser modificado dependendo da solucao
erro = 0.0001 # pode ser modificado dependendo da estimativa de erro desejada
iteracao = 1

while True:
  #calculando as iteracoes(utiliza as funcoes f() e df())
  xk = x0 - f(x0)/df(x0)
  # mostrando os valores por iteracao conforme elas acontecem
  print('Valor de x', iteracao, ': [', xk, ']', 'Valor estimado do Erro', ':[', math.fabs(xk-x0), ']')
  #verifica se chegou ao limite do erro proposto
  if math.fabs(xk-x0)<erro:
    break;
  else:
    x0 = xk
  iteracao = iteracao + 1


# Mostrando os valores finais
print('\n')
print('Valor final de x: [',xk,']')
print('Estimativa final do erro |xn-xn+1|: ',math.fabs(xk-x0))
