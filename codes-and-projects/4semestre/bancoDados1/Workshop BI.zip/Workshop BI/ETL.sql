-- CREATE DATABASE datawarehouse_bi;

CREATE TABLE datawarehouse_bi.PRODUTO AS
SELECT
	ProdutoID
    ,NomeProduto
    ,Categoria
FROM 
	PRODUCAO.PRODUTO;

CREATE TABLE datawarehouse_bi.STATUSVENDA AS
SELECT
	StatusVendaID
    ,DescricaoStatus
FROM 
	PRODUCAO.STATUSVENDA;

CREATE TABLE datawarehouse_bi.VENDEDORES AS 
SELECT
	VendedorID
    ,NomeVendedor
    ,Regiao
FROM 
	PRODUCAO.VENDEDORES;

CREATE TABLE datawarehouse_bi.CLIENTE AS
SELECT
	ClienteID
    ,NomeCliente
    ,TRIM(SUBSTR(ENDERECO, LOCATE(', ', ENDERECO)+1, 1000)) 	Cidade
    ,TRIM(SUBSTR(ENDERECO, 1, LOCATE(', ', ENDERECO)-1))		Logradouro
    ,Endereco
FROM 
	PRODUCAO.CLIENTE;

CREATE TABLE datawarehouse_bi.VENDAS AS
SELECT
	VendaID
    ,DataVenda
    ,ValorVenda
    ,VendedorID
    ,ProdutoID
    ,StatusVendaID
    ,ClienteID
FROM 
	PRODUCAO.VENDAS;

-- PRIMARY KEY
ALTER TABLE Vendedores
ADD PRIMARY KEY (VendedorID);

ALTER TABLE Produto
ADD PRIMARY KEY (ProdutoID);

ALTER TABLE StatusVenda
ADD PRIMARY KEY (StatusVendaID);

ALTER TABLE Cliente
ADD PRIMARY KEY (ClienteID);

-- CHAVES ESTRANGEIRAS
ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Vendedor
FOREIGN KEY (VendedorID)
REFERENCES Vendedores(VendedorID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Produto
FOREIGN KEY (ProdutoID)
REFERENCES Produto(ProdutoID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_StatusVenda
FOREIGN KEY (StatusVendaID)
REFERENCES StatusVenda(StatusVendaID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Cliente
FOREIGN KEY (ClienteID)
REFERENCES Cliente(ClienteID);