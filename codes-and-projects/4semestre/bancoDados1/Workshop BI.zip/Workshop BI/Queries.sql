-- TABELAS BANCO DE PRODUÇÃO
CREATE TABLE Vendas (
    VendaID INT PRIMARY KEY,
    DataVenda DATE,
    ValorVenda DECIMAL(10, 2),
    VendedorID INT,
    ProdutoID INT,
    StatusVendaID INT,
    ClienteID INT
);

CREATE TABLE Vendedores (
    VendedorID INT PRIMARY KEY,
    NomeVendedor VARCHAR(255),
    Regiao VARCHAR(255)
);

CREATE TABLE Produto (
    ProdutoID INT PRIMARY KEY,
    NomeProduto VARCHAR(255),
    Categoria VARCHAR(255),
    Preco DECIMAL(10, 2)
);

CREATE TABLE StatusVenda (
    StatusVendaID INT PRIMARY KEY,
    DescricaoStatus VARCHAR(255)
);

CREATE TABLE Cliente (
    ClienteID INT PRIMARY KEY,
    NomeCliente VARCHAR(255),
    Endereco VARCHAR(255)
);

-- CHAVES ESTRANGEIRAS
ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Vendedor
FOREIGN KEY (VendedorID)
REFERENCES Vendedores(VendedorID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Produto
FOREIGN KEY (ProdutoID)
REFERENCES Produto(ProdutoID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_StatusVenda
FOREIGN KEY (StatusVendaID)
REFERENCES StatusVenda(StatusVendaID);

ALTER TABLE Vendas
ADD CONSTRAINT FK_Vendas_Cliente
FOREIGN KEY (ClienteID)
REFERENCES Cliente(ClienteID);

-- INSERINDO DADOS NA TABELA
INSERT INTO Produto (ProdutoID, NomeProduto, Categoria, Preco)
VALUES
    (1, 'Televisão', 'Eletrônicos', 599.99),
    (2, 'Calça Jeans', 'Roupas', 199.99),
    (3, 'Sofá', 'Móveis', 499.99)
    -- Insira mais produtos conforme necessário
;

INSERT INTO Vendedores (VendedorID, NomeVendedor, Regiao)
VALUES
    (1, 'Adriano Sanches', 'Sul'),
    (2, 'Bruna Ribeiro', 'Sul'),
    (3, 'Renan Alberto', 'Sul')
    -- Insira mais vendedores conforme necessário
;

INSERT INTO StatusVenda (StatusVendaID, DescricaoStatus)
VALUES
    (1, 'Em andamento'),
    (2, 'Concluída'),
    (3, 'Cancelada')
    -- Insira mais status de venda conforme necessário
;

INSERT INTO Cliente (ClienteID, NomeCliente, Endereco)
VALUES
    (1, 'José Abreu', 'Rua A, Itajaí'),
    (2, 'Mariana Andrade', 'Rua B, Itajaí'),
    (3, 'Rafael Duarte', 'Rua C, Florianópolis'),
    (4, 'Marcos Henrique', 'Rua C, Florianópolis'),
    (5, 'Gustavo Ribeiro', 'Rua C, Florianópolis'),
    (6, 'Lucas Rafael', 'Rua C, Itajaí'),
    (7, 'Ediano Esquina', 'Rua C, Itajaí'),
    (8, 'Clemente Santos', 'Rua C, Porto Belo'),
    (9, 'Bruna Rafaela', 'Rua C, Itapema'),
    (10, 'Matheus Henrique', 'Rua C, Itapema')
;

-- Vendas com base nas dimensões existentes
INSERT INTO Vendas (VendaID, DataVenda, ValorVenda, VendedorID, ProdutoID, StatusVendaID, ClienteID)
VALUES
    (1, '2023-01-15', 500.00, 1, 1, 2, 1),
    (2, '2023-01-16', 700.00, 2, 2, 2, 2), 
    (3, '2023-01-17', 350.00, 1, 3, 1, 3),
    (4, '2023-01-18', 450.00, 3, 1, 2, 4),
    (5, '2023-01-19', 900.00, 2, 3, 2, 5),
    (6, '2023-01-20', 600.00, 1, 2, 1, 6),
    (7, '2023-01-21', 300.00, 2, 1, 1, 7),
    (8, '2023-01-22', 750.00, 3, 2, 2, 8),
    (9, '2023-01-23', 400.00, 1, 3, 1, 9),
    (10, '2023-01-24', 985.00, 1, 3, 2, 1),
    (11, '2023-01-15', 321.00, 3, 1, 2, 1),
    (12, '2023-01-15', 700.00, 2, 2, 2, 1), 
    (13, '2023-01-15', 435.00, 3, 2, 3, 2),
    (14, '2023-01-09', 123.00, 1, 1, 2, 2),
    (15, '2023-01-09', 33.00, 1, 1, 2, 3),
    (16, '2023-01-09', 4545.00, 2, 1, 1, 3),
    (17, '2023-01-11', 123.00, 3, 2, 1, 1),
    (18, '2023-01-22', 546.00, 2, 3, 3, 2),
    (19, '2023-01-22', 776.00, 1, 3, 3, 3),
    (20, '2023-01-22', 998.00, 2, 1, 1, 10);