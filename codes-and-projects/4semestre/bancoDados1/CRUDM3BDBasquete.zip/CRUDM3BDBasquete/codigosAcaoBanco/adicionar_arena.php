<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title>Arenas</title>
  <link rel="stylesheet" href="./style/styles.css" />
  <link rel="icon" href="https://logospng.org/download/nba/logo-nba-4096.png" type="image/x-icon" />

</head>

<body id="page-top">
  <?php

  if (isset($_POST['nomeArena'])) {

    require './classes/Arena.php';

    $cli = new Arena();
    $cli->inserir($_POST['nomeArena'], $_POST['capacidadeArena'], $_POST['FK_idCidade']);
  }

  ?>

  <?php if (isset($_POST['nomeArena'])) { ?>
    <script>
      alert('Arena inserida com sucesso!');
    </script>
  <?php } ?>

  <header>
    <nav>
      <a href="index.php"><img src="https://logospng.org/download/nba/logo-nba-4096.png" alt="Basketball Logo" /></a>
      <ul>
        <li><a href="../index.php">Home</a></li>
        <li><a href="equipe.php">Equipes</a></li>
        <li><a href="jogador.php">Jogadores</a></li>
        <li><a href="treinador.php">Treinadores</a></li>
        <li><a href="arena.php" class="active">Arenas</a></li>
        <li><a href="cidade.php">Cidades</a></li>
        <li><a href="estado.php">Estados</a></li>
      </ul>
    </nav>
  </header>

  <section id="hero">
    <div id="form">
      <center>
        <form action="./codigosAcaoBanco/adicionar_arena.php" method="post">
          <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
            <label for="nome" class="form-label" style="text-align: inherit;color:#fff">Nome:</label>
            <input type="text" class="form-control" id="nomeArena" name="nomeArena">
          </div>
          <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
            <label for="telefone" class="form-label" style="color: #fff;">Capacidade:</label>
            <input type="tel" class="form-control" id="capacidadeArena" name="capacidadeArena" placeholder="...">
          </div>
          <div class="mb-3 col-10 col-md-12" style="text-align: initial;">
            <label for="email" class="form-label" style="color: #fff;">Cidade:</label>
            <input type="text" class="form-control" id="FK_idCidade" name="FK_idCidade" placeholder="...">
          </div>
          <div class="row">
            <div class="col-12 col-md-12">
              <button class="btn btn-outline-light" type="submit">Enviar</button>
            </div>
          </div>
          <br />
          <div class="col-12 col-md-12">
            <a href="index.php" class="btn btn-primary">Voltar ao início</a>
            <a class="btn btn-primary" href="./codigosAcaoBanco/adicionar_arena.php">Adicionar Cliente</a>
          </div>
        </form>
      </center>
    </div>
  </section>

  <!-- Footer-->
  <footer>
    <span>&copy; Desenvolvido por Gustavo Baron Lauritzen, Matheus Baron Lauritzen e Gabriel Bósio - 2023</span>
  </footer>


</body>

</html>