<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Arenas</title>

    <!-- Font Awesome icons-->
    <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />

    <link rel="icon" type="image/x-icon" href="./assets/icon_basquete.png" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <link href="./style/styles.css" rel="stylesheet" />

</head>

<body id="page-top">
    <?php

    require './classes/Jogador.php';
    $jogador = new Arena();

    //Pagination
    $pagina = 1;

    if (isset($_GET['pagina']))
        $pagina = filter_input(INPUT_GET, "pagina", FILTER_VALIDATE_INT);

    if (!$pagina)
        $pagina = 1;

    $limite = 10;

    $inicio = ($pagina * $limite) - $limite;

    if (isset($pesquisa)) {
    }
    $listaDeJogador = $jogador->listar($inicio, $limite)->fetchAll();

    $registros = $jogador->contar()->fetch()["count"];

    $paginas = ceil($registros / $limite);

    ?>

    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg bg-dark fixed-top" id="mainNav">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php"><img src="./assets/icon_basquete.png" alt="..." style="width: 80px;height: 80px;"> Início</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <div class="container">
                            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                                <div class="container-fluid">
                                    <a class="navbar-brand" href="jogador.php">Jogadores</a>
                                </div>
                            </nav>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="masthead">
        <div class="d-flex px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
            <div class="text-center">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <a class="btn btn-outline-light" href="index.php"><i class="fas fa-arrow-alt-circle-left"></i> Voltar ao Início</a>
                        <a class="btn btn-outline-primary" href="./codigosAcaoBanco/adicionar_jogador.php"><i class="fas fa-plus-circle"></i> Adicionar Jogador</a>
                    </div>
                </div>
                <br />

                <form class="d-flex">
                    <input class="form-control mr-2" type="search" placeholder="Search..." aria-label="Search" name="busca">
                    <button class="btn btn-outline-primary " type="submit" onclick=""><i class="fas fa-search"></i></button>
                </form>

                <br />
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <td><i class="fas fa-hashtag"></i> ID</td>
                            <td><i class="fas fa-user"></i> Nome</td>
                            <td><i class="fas fa-baby-carriage"></i> Data de nascimento</td>
                            <td><i class="fas fa-user-tag"></i> Posição </td>
                            <td><i class="fas fa-ruler-vertical"></i> Altura</td>
                            <td><i class="fas fa-weight-hanging"></i> Peso</td>
                            <td><i class="fas fa-users"></i> Equipe</td>
                            <td><i class="fas fa-tasks"></i> Ações</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listaDeJogador as $a) { ?>
                            <tr>
                                <td><i class="fas fa-hashtag"> <?php echo $a['idJogador']; ?></td>
                                <td><i class="fas fa-user"> <?php echo $a['nomeJogador']; ?></td>
                                <td><i class="fas fa-baby-carriage"></i> <?php echo $a['dataNascimento']; ?></td>
                                <td><i class="fas fa-user-tag"></i> <?php echo $a['posicaoJogador']; ?></td>
                                <td><i class="fas fa-ruler-vertical"></i> <?php echo $a['alturaJogador']; ?></td>
                                <td><i class="fas fa-weight-hanging"></i> <?php echo $a['pesoJogador']; ?></td>
                                <td><i class="fas fa-users"></i> <?php echo $a['FK_idEquipe']; ?></td>
                                <td>
                                    <a href="eliminar_arena.php?idArena=<?php echo $a['idArena']; ?>" style="text-decoration: none;">
                                        <i class="fas fa-times-circle"></i> Eliminar
                                    </a>
                                    <a href="editar_arena.php?idArena=<?php echo $a['idArena'] ?>" style="text-decoration: none;">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <!--Pagination-->
                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item"><a class="page-link bg-dark" href="?pagina=1" aria-label="First">Primeira</a></li>
                        <?php if ($pagina > 1) { ?>
                            <li class="page-item"><a class="page-link bg-dark" href="?pagina=<?= $pagina - 1 ?>" aria-label="Previous"><span aria-hidden="true">
                                        << </span></a></li>
                        <?php } ?>
                        <li class="page-item"><a class="page-link bg-dark" href="" aria-label="Current" style="pointer-events: none; text-decoration: none;"><?= $pagina ?></a></li>
                        <?php if ($pagina < $paginas) { ?>
                            <li class="page-item"><a class="page-link bg-dark" href="?pagina=<?= $pagina + 1 ?>" aria-label="Next"><span aria-hidden="true"> >> </span></a></li>
                        <?php } ?>
                        <li class="page-item"><a class="page-link bg-dark" href="?pagina=<?= $paginas ?>" aria-label="Last">Última</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <div class="d-flex justify-content-center" style="background-color: #212529;font-size: 20px;">
        <div class="text-center">
            <!-- Footer-->
            <footer class="footer small text-center text-white-50">
                <div class="container px-4 px-lg-5">Copyright &copy; Desenvolvido por Gustavo Baron Lauritzen, Matheus Baron Lauritzen e Gabriel Bósio 2023</div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- SB Forms JS -->
    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

</body>

</html>