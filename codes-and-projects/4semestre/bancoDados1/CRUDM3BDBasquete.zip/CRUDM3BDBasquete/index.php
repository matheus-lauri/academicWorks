<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>CRUD Basquete</title>
  <link rel="icon" type="image/x-icon" href="./assets/icon_basquete.png" />
  <!-- Font Awesome icons-->
  <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
  <!-- Google fonts-->
  <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />

  <link href="./style/styles.css" rel="stylesheet" />
</head>

<body id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg bg-dark fixed-top" id="mainNav">
    <div class="container px-4 px-lg-5">
      <a class="navbar-brand" href="index.php"><img src="./assets/icon_basquete.png" alt="..." style="width: 80px;height: 80px;"> Início</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <div class="dropdown">
              <button class="btn btn-dark dropdown-toggle" style="width: 250px;text-shadow: none;" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Tabelas
              </button>
              <ul class="dropdown-menu dropdown-menu-dark" style="width: 250px;text-align: center;font-size: 15px;">
                <li><a class="dropdown-item" href="arena.php">Arena</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Cidade</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Classificação</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Equipe</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Estado</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Jogador</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Lesão</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Partida</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Patrocinador</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Premiação</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Temporada</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="teste.php">Treinador</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Masthead-->
  <header class="masthead-index">
    <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
      <div class="d-flex justify-content-center">
        <div class="text-center">
          <a href="index.php" style="text-decoration: none">
            <h1 class="mx-auto my-0 text-uppercase">CRUD</h1>
          </a>
          <h2 class="text-white-50 mx-auto mt-2 mb-5">CRUD com o tema de basquete para a disciplina de Banco de Dados I</h2>
        </div>
      </div>
    </div>
  </header>

  <div class="d-flex justify-content-center" style="background-color: #212529;font-size: 20px;">
    <div class="text-center">
      <!-- Footer-->
      <footer class="footer small text-center text-white-50">
        <div class="container px-4 px-lg-5">Copyright &copy; Desenvolvido por Gustavo Baron Lauritzen, Matheus Baron Lauritzen e Gabriel Bósio 2023</div>
      </footer>
    </div>
  </div>

  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="js/scripts.js"></script>
  <!-- SB Forms JS -->
  <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
</body>

</html>