<?php

require 'Conexao.php';

class Arena
{

    private $conexao;

    public function __construct()
    {
        $con = new Conexao();
        $this->conexao = $con->getConexao();
    }

    public function pesquisar($inicio, $limite, $pesquisa)
    {
        // Adiciona curingas à variável de pesquisa para usar com LIKE
        $pesquisa = "%{$pesquisa}%";

        // Prepara a instrução SQL usando uma instrução preparada
        $sql = "SELECT * FROM arena WHERE nomeArena LIKE ? AND statusArena = 1 LIMIT ?, ?";
        $q = $this->conexao->prepare($sql);

        // Verifica se a preparação foi bem-sucedida
        if (!$q) {
            die('Erro na preparação da consulta: ' . $this->conexao->errorInfo());
        }

        // Liga os parâmetros
        $q->bindParam(1, $pesquisa, PDO::PARAM_STR);
        $q->bindParam(2, $inicio, PDO::PARAM_INT);
        $q->bindParam(3, $limite, PDO::PARAM_INT);

        // Executa a consulta
        $q->execute();

        // Retorna o resultado
        return $q;
    }


    public function listar($inicio, $limite)
    {
        $sql = "SELECT * FROM arena WHERE statusArena = 1 LIMIT $inicio, $limite;";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;
    }

    public function contar()
    {
        $sql = "SELECT COUNT(nomeArena) count FROM arena;";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;
    }

    public function inserir($nomeArena, $capacidadeArena, $FK_idCidade)
    {

        $sql = 'INSERT INTO arena (nomeArena, capacidadeArena, FK_idCidade) VALUES (?, ?, ?)';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeArena);
        $q->bindParam(2, $capacidadeArena);
        $q->bindParam(3, $FK_idCidade);

        $q->execute();
    }

    public function getArena($idArena)
    {

        $sql = 'SELECT * FROM arena WHERE idArena = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idArena);

        $q->execute();

        $arena = [];

        foreach ($q as $a) {
            $arena = $a;
        }

        return $arena;
    }

    public function editar($idArena, $nomeArena)
    {

        $sql = 'UPDATE arena SET nomeArena = ? WHERE idArena = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeArena);
        $q->bindParam(2, $idArena);

        $q->execute();
    }

    public function eliminar($idArena)
    {

        $sql = "DELETE FROM arena WHERE idArena = ?";

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idArena);

        $q->execute();
    }
}
