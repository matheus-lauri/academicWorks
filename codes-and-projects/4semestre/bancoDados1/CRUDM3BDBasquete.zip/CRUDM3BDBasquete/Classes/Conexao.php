<?php

class Conexao
{

    private $username;
    private $password;
    private $database;
    private $host;

    public function __construct()
    {
        $this->username = 'root';
        $this->password = '';
        $this->host = 'localhost';
        $this->database = 'basquete_M2_database';
    }

    public function getConexao()
    {

        $con = $this->getConexaoMySql();

        return $con;
    }

    public function getConexaoMySql()
    {

        $dsnMysql = 'mysql:host=' . $this->host . ';dbname=' . $this->database;

        $con = new \PDO($dsnMysql, $this->username, $this->password);

        return $con;
    }
}
