<?php

require 'Conexao.php';

class Jogador
{

    private $conexao;

    public function __construct()
    {
        $con = new Conexao();
        $this->conexao = $con->getConexao();
    }

    public function listar($inicio, $limite)
    {
        $sql = "SELECT * FROM jogador LIMIT $inicio, $limite;";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;
    }

    public function contar()
    {
        $sql = "SELECT COUNT(nomeJogador) count FROM jogador;";
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;
    }
    # idJogador, nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, statusJogador, FK_idEquipe
    public function inserir($nomeJogador, $dataNascimentoJogador, $posicaoJogador, $alturaJogador, $pesoJogador, $statusJogador, $FK_idEquipe)
    {

        $sql = 'INSERT INTO arena ( nomeJogador, dataNascimentoJogador, posicaoJogador, alturaJogador, pesoJogador, statusJogador, FK_idEquipe) VALUES (?, ?, ?, ?, ?, ?, ?)';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeJogador);
        $q->bindParam(2, $dataNascimentoJogador);
        $q->bindParam(3, $posicaoJogador);
        $q->bindParam(4, $alturaJogador);
        $q->bindParam(5, $pesoJogador);
        $q->bindParam(6, $statusJogador);
        $q->bindParam(7, $FK_idEquipe);

        $q->execute();
    }

    public function getJogador($idJogador)
    {

        $sql = 'SELECT * FROM jogador WHERE idJogador = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idJogador);

        $q->execute();

        $jogador = [];

        foreach ($q as $a) {
            $jogador = $a;
        }

        return $jogador;
    }

    public function editar($idArena, $nomeArena)
    {

        $sql = 'UPDATE jogador SET nomeJogador = ? WHERE idJogador = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomeArena);
        $q->bindParam(2, $idArena);

        $q->execute();
    }

    public function eliminar($idArena)
    {

        $sql = "DELETE FROM arena WHERE idArena = ?";

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $idArena);

        $q->execute();
    }
}
