#include <iostream>
#include <fstream>
#include <string>
#include "lde.h"

// Desenvolvido por Matheus Baron Lauritzen e Gustavo Baron Lauritzen

using namespace std;

struct Organizacao {
	int cpiPipeline;
	float totalCiclos, contadorInstrucaoOriginal, contadorInstrucaoFinal, tempoClock, tempoExecucaoCPU;
};

struct Instrucao {
	string instCompleta, opCode, rs1, rs2, rd;
};

void calcularImprimirDesempenho(Organizacao& orgA, Organizacao& orgB) {

	

}

//  Indice baseado em 0 do primeiro caractere que voce  deseja pegar e  indice baseado em 0 do ultimo caractere que voce deseja pegar
void leBinarioArquivoEscreveLista(Organizacao& org, LDE <string>& lista, string nomeArquivo) {
	ifstream file(nomeArquivo);
	int start = 0;
	int end = 31;
	org.contadorInstrucaoOriginal = 0;
	string instrucao;
	if (!file.is_open()) {
		cout << "Nao foi possivel abrir o arquivo." << endl;
		return;
	}
	string line;
	while (getline(file, line)) {

		if (start >= 0 && end < line.length()) {
			instrucao = line.substr(start, end - start + 1);
			inserirFinalLDE(lista, instrucao);
			org.contadorInstrucaoOriginal++;
		}
		else {
			cout << "Intervalo fora dos limites da linha." << endl;
		}
	}
	file.close();
}

string verificaInstrucao(string inst) {
	int startOpcode = 25, endOpcode = 31;
	Instrucao instrucao;

	instrucao.opCode = inst.substr(startOpcode, endOpcode - startOpcode + 1);

	if (inst == "00000000000000000000000000010011") {
		return "NOP";
	}
	else if (instrucao.opCode == "0110111" || instrucao.opCode == "0010111") {  //instrucao tipo U  
		return "U";
	}
	else if (instrucao.opCode == "1101111" || instrucao.opCode == "1100111") { //instrucao tipo J
		return "J";
	}
	else if (instrucao.opCode == "1100011") { //instrucao tipo B
		return "B";
	}
	else if (instrucao.opCode == "0000011") { //instrucao tipo I memoria
		return "IM";
	}
	else if (instrucao.opCode == "0100011") { //instrucao tipo S
		return "S";
	}
	else if (instrucao.opCode == "0010011" || instrucao.opCode == "1110011") { //instrucao tipo I aritmetico e ecall
		return "IAE";
	}
	else if (instrucao.opCode == "0110011") { //instrucao tipo R
		return "R";
	}
	return 0;
}

void insere2Nop(LDE<string>& lista, No<string>*& aux) {
	No <string>* proximo = new No <string>;
	No <string>* nop1 = new No <string>;
	No <string>* nop2 = new No <string>;

	//dump Nop 32bits = 00000000000000000000000000010011 ******* addi zero, zero, 0
	nop1->info = "00000000000000000000000000010011"; // addi zero, zero, 0
	nop2->info = "00000000000000000000000000010011"; // addi zero, zero, 0

	//inserindo 2 nop
	proximo = aux->eloP;
	aux->eloP = nop1;
	nop1->eloA = aux;
	nop1->eloP = nop2;
	nop2->eloA = nop1;
	nop2->eloP = proximo;
	proximo->eloA = nop2;
}

void insere1Nop(LDE<string>& lista, No<string>*& aux) {
	No <string>* proximo = new No <string>;
	No <string>* nop1 = new No <string>;

	nop1->info = "00000000000000000000000000010011"; // addi zero, zero, 0

	//inserindo 1 nop
	proximo = aux->eloP;
	aux->eloP = nop1;
	nop1->eloA = aux;
	nop1->eloP = proximo;
	proximo->eloA = nop1;

}

void escreveListaParaTxt(LDE<string> lista, string nomeArquivo) {
	ofstream arquivo(nomeArquivo);

	if (!arquivo.is_open()) {
		cout << "N�o foi poss�vel abrir o arquivo." << endl;
		return;
	}

	No<string>* atual = lista.comeco;

	while (atual != nullptr) {
		arquivo << atual->info << endl;
		atual = atual->eloP;
	}

	arquivo.close();
}

void solucao2(LDE <string>& listaOriginal) {
	int startOpcode = 25, endOpcode = 31;
	int startRd = 20, endRd = 24;
	int startRs1 = 12, endRs1 = 16;
	int startRs2 = 7, endRs2 = 11;
	string retornoInst1 = "", retornoInst2 = "", retornoAux = "";
	Instrucao instrucao;
	No <string>* auxproximo1 = new No <string>;
	No <string>* auxproximo2 = new No <string>;
	No <string>* aux = new No <string>;
	aux = listaOriginal.comeco;

	if (listaOriginal.comeco != NULL) {
		while (aux != NULL) {
			instrucao.opCode = aux->info.substr(startOpcode, endOpcode - startOpcode + 1);
			instrucao.rd = aux->info.substr(startRd, endRd - startRd + 1);
			instrucao.rs1 = aux->info.substr(startRs1, endRs1 - startRs1 + 1);
			instrucao.rs2 = aux->info.substr(startRs2, endRs2 - startRs2 + 1);
			instrucao.instCompleta = aux->info;


			if (aux->eloP != nullptr) {
				auxproximo1 = aux->eloP;
				if (aux->eloP->eloP != nullptr) {
					auxproximo2 = aux->eloP->eloP;
				}
				else {
					auxproximo2 = nullptr;
				}
			}
			else {
				auxproximo1 = nullptr;
			}

			retornoAux = verificaInstrucao(aux->info);
			if (auxproximo1 != nullptr) {
				retornoInst1 = verificaInstrucao(auxproximo1->info);
				if (auxproximo2 != nullptr) {
					retornoInst2 = verificaInstrucao(auxproximo2->info);
				}
			}

			if (retornoAux == "NOP") {
				aux = aux->eloP;
				continue;
			}

			if (retornoAux == "IM") {
				if (auxproximo1 != nullptr) {
					if (retornoInst1 == "J") {
						insere1Nop(listaOriginal, aux);
						aux = aux->eloP;
						continue;
					}
					else if ((retornoInst1 == "B") || (retornoInst1 == "S") || (retornoInst1 == "R")) {
						if ((instrucao.rd == auxproximo1->info.substr(startRs1, endRs1 - startRs1 + 1)) || (instrucao.rd == auxproximo1->info.substr(startRs2, endRs2 - startRs2 + 1))) {
							insere1Nop(listaOriginal, aux);
							aux = aux->eloP;
							continue;
						}
					}
					else if ((retornoInst1 == "IM") || (retornoInst1 == "IAE")) {
						if (instrucao.rd == auxproximo1->info.substr(startRs1, endRs1 - startRs1 + 1)) {
							insere1Nop(listaOriginal, aux);
							aux = aux->eloP;
							continue;
						}
					}
				}
			}

			aux = aux->eloP;

		}
	}
}

void solucao1(LDE <string>& listaOriginal) {
	int startOpcode = 25, endOpcode = 31;
	int startRd = 20, endRd = 24;
	int startRs1 = 12, endRs1 = 16;
	int startRs2 = 7, endRs2 = 11;
	string retornoInst1 = "", retornoInst2 = "", retornoAux = "";
	Instrucao instrucao;
	No <string>* auxproximo1 = new No <string>;
	No <string>* auxproximo2 = new No <string>;
	No <string>* aux = new No <string>;
	aux = listaOriginal.comeco;

	if (listaOriginal.comeco != NULL) {
		while (aux != NULL) {
			instrucao.opCode = aux->info.substr(startOpcode, endOpcode - startOpcode + 1);
			instrucao.rd = aux->info.substr(startRd, endRd - startRd + 1);
			instrucao.rs1 = aux->info.substr(startRs1, endRs1 - startRs1 + 1);
			instrucao.rs2 = aux->info.substr(startRs2, endRs2 - startRs2 + 1);
			instrucao.instCompleta = aux->info;


			if (aux->eloP != nullptr) {
				auxproximo1 = aux->eloP;
				if (aux->eloP->eloP != nullptr) {
					auxproximo2 = aux->eloP->eloP;
				}
				else {
					auxproximo2 = nullptr;
				}
			}
			else {
				auxproximo1 = nullptr;
			}

			retornoAux = verificaInstrucao(aux->info);
			if (auxproximo1 != nullptr) {
				retornoInst1 = verificaInstrucao(auxproximo1->info);
				if (auxproximo2 != nullptr) {
					retornoInst2 = verificaInstrucao(auxproximo2->info);
				}
			}

			if (retornoAux == "NOP") {
				aux = aux->eloP;
				continue;
			}

			if (retornoAux == "IAE" || retornoAux == "U" || retornoAux == "IM" || retornoAux == "R") {
				if (auxproximo1 != nullptr) {
					if (retornoInst1 == "J") {
						insere1Nop(listaOriginal, aux);
						aux = aux->eloP;
						continue;
					} else if ((retornoInst1 == "B") || (retornoInst1 == "S") || (retornoInst1 == "R")) {
						if ((instrucao.rd == auxproximo1->info.substr(startRs1, endRs1 - startRs1 + 1)) || (instrucao.rd == auxproximo1->info.substr(startRs2, endRs2 - startRs2 + 1))) {
							insere2Nop(listaOriginal, aux);
							aux = aux->eloP;
							continue;
						}
					} else if ((retornoInst1 == "IM") || (retornoInst1 == "IAE")) {
						if (instrucao.rd == auxproximo1->info.substr(startRs1, endRs1 - startRs1 + 1)) {
							insere2Nop(listaOriginal, aux);
							aux = aux->eloP;
							continue;
						}
					}
					if (auxproximo2 != nullptr) {
						if (retornoInst2 == "J") {
							aux = aux->eloP;
							continue;
						} else if ((retornoInst2 == "B") || (retornoInst2 == "S") || (retornoInst2 == "R")) {
							if ((instrucao.rd == auxproximo2->info.substr(startRs1, endRs1 - startRs1 + 1)) || (instrucao.rd == auxproximo2->info.substr(startRs2, endRs2 - startRs2 + 1))) {
								insere1Nop(listaOriginal, auxproximo1);
								aux = aux->eloP;
								continue;
							}
						} else if ((retornoInst2 == "IM") || (retornoInst2 == "IAE")) {
							if (instrucao.rd == auxproximo2->info.substr(startRs1, endRs1 - startRs1 + 1)) {
								insere1Nop(listaOriginal, auxproximo1);
								aux = aux->eloP;
								continue;
							}
						}
					}
				}
			}

			aux = aux->eloP;

		}
	}
}

void menuEntradaDadosOrg(Organizacao& org) {
	cout << "Insira o tempo de clock do Pipeline:" << endl;
	cin >> org.tempoClock;
}

void gerenciarCalculoOrganizacao() {
	Organizacao org;
	LDE <string> listaOriginal1, listaOriginal2, listaOriginal3, listaOriginal4;
	inicializarLDE(listaOriginal1);
	inicializarLDE(listaOriginal2);
	inicializarLDE(listaOriginal3);
	inicializarLDE(listaOriginal4);
	menuEntradaDadosOrg(org);
	//solucao 1
	leBinarioArquivoEscreveLista(org, listaOriginal1, "DumpBinario1.txt");
	solucao1(listaOriginal1);
	escreveListaParaTxt(listaOriginal1, "DumpSolucao1.txt");
	//solucao 2
	leBinarioArquivoEscreveLista(org, listaOriginal2, "DumpBinario2.txt");
	solucao2(listaOriginal2);
	escreveListaParaTxt(listaOriginal2, "DumpSolucao2.txt");
	//solucao 3
	//...
	//solucao 4
	//...
	cout << "Pronto" << endl;
	system("Pause");
}

//Menu inicial
int menuInicial() {
	int escolhaMenuInicial;
	do {
		cout << "Bem vindo ao Calculo de Instrucoes" << endl;
		cout << "1 - Entrar" << endl;
		cout << "2 - Sair" << endl;
		cin >> escolhaMenuInicial;
		switch (escolhaMenuInicial) {
		case 1:
			system("cls");
			gerenciarCalculoOrganizacao();
			return 0;
			break;
		case 2:
			system("cls");
			return 0;
			break;
		default:
			cout << "Opcao invalida. Tente novamente." << endl;
			system("pause");
			system("cls");
		}
	} while (escolhaMenuInicial != 1 && escolhaMenuInicial != 2);
	return 0;
}

int main() {
	menuInicial();
	return 0;
}
