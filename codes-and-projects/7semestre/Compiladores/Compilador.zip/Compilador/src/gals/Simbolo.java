package gals;

public class Simbolo {
    private String id;
    private String tipo;
    private boolean inicializada;
    private boolean usada;
    private int escopo;
    private boolean parametro;
    private int posicao;
    private boolean vetor;
    private boolean referencia;
    private boolean funcao;
    private String nomeFuncao;

    // Construtor
    public Simbolo(String id, String tipo, boolean inicializada, boolean usada, int escopo, 
                          boolean parametro, int posicao, boolean vetor, 
                          boolean referencia, boolean funcao, String nomeFuncao) {
        this.id = id;
        this.tipo = tipo;
        this.inicializada = inicializada;
        this.usada = usada;
        this.escopo = escopo;
        this.parametro = parametro;
        this.posicao = posicao;
        this.vetor = vetor;
        this.referencia = referencia;
        this.funcao = funcao;
        this.nomeFuncao = nomeFuncao;
    }

    public Simbolo() {
        this.id = "";
        this.tipo = "";
        this.inicializada = false;
        this.usada = false;
        this.escopo = 0;
        this.parametro = false;
        this.posicao = 0;
        this.vetor = false;
        this.referencia = false;
        this.funcao = false;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public boolean getInicializada() {
        return inicializada;
    }

    public boolean getUsada() {
        return usada;
    }

    public int getEscopo() {
        return escopo;
    }

    public boolean getParametro() {
        return parametro;
    }

    public int getPosicao() {
        return posicao;
    }

    public boolean getVetor() {
        return vetor;
    }

    public boolean getReferencia() {
        return referencia;
    }

    public boolean getFuncao() {
        return funcao;
    }

    public String getNomeFuncao() {
        return nomeFuncao;
    }

    // Setters
    public void setUsada(boolean usada) {
        this.usada = usada;
    }

    public void setInicializada(boolean inicializada) {
        this.inicializada = inicializada;
    }
    
}