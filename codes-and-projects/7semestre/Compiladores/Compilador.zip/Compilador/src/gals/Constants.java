package gals;

public interface Constants extends ScannerConstants, ParserConstants
{
    int EPSILON  = 0;
    int DOLLAR   = 1;

    int t_BREAK = 2;
    int t_CASE = 3;
    int t_CONTINUE = 4;
    int t_DO = 5;
    int t_ELSE = 6;
    int t_FOR = 7;
    int t_IF = 8;
    int t_END = 9;
    int t_RETURN = 10;
    int t_SWITCH = 11;
    int t_WHILE = 12;
    int t_FUNCTION = 13;
    int t_VOID = 14;
    int t_COMMENT_LINE = 15;
    int t_MULTIPLE_COMMENT = 16;
    int t_LITERAL_INT = 17;
    int t_LITERAL_REAL = 18;
    int t_LITERAL_BIN = 19;
    int t_LITERAL_HEXA = 20;
    int t_LITERAL_CHAR = 21;
    int t_LITERAL_STRING = 22;
    int t_LITERAL_BOOL = 23;
    int t_TOKEN_24 = 24; //";"
    int t_TOKEN_25 = 25; //","
    int t_TOKEN_26 = 26; //":"
    int t_TOKEN_27 = 27; //"."
    int t_TOKEN_28 = 28; //"("
    int t_TOKEN_29 = 29; //")"
    int t_TOKEN_30 = 30; //"{"
    int t_TOKEN_31 = 31; //"}"
    int t_TOKEN_32 = 32; //"["
    int t_TOKEN_33 = 33; //"]"
    int t_ID = 34;
    int t_KEY_CHAR = 35;
    int t_KEY_CONST = 36;
    int t_KEY_DOUBLE = 37;
    int t_KEY_INT = 38;
    int t_KEY_LONG = 39;
    int t_KEY_SHORT = 40;
    int t_KEY_STRING = 41;
    int t_KEY_FLOAT = 42;
    int t_KEY_BOOL = 43;
    int t_SCAN = 44;
    int t_PRINT = 45;
    int t_TOKEN_46 = 46; //"+"
    int t_TOKEN_47 = 47; //"-"
    int t_TOKEN_48 = 48; //"*"
    int t_TOKEN_49 = 49; //"/"
    int t_TOKEN_50 = 50; //"%"
    int t_TOKEN_51 = 51; //">"
    int t_TOKEN_52 = 52; //"<"
    int t_TOKEN_53 = 53; //">="
    int t_TOKEN_54 = 54; //"<="
    int t_TOKEN_55 = 55; //"=="
    int t_TOKEN_56 = 56; //"!="
    int t_TOKEN_57 = 57; //"&&"
    int t_TOKEN_58 = 58; //"||"
    int t_TOKEN_59 = 59; //"!"
    int t_TOKEN_60 = 60; //"~"
    int t_TOKEN_61 = 61; //">>"
    int t_TOKEN_62 = 62; //"<<"
    int t_TOKEN_63 = 63; //"^"
    int t_TOKEN_64 = 64; //"|"
    int t_TOKEN_65 = 65; //"&"
    int t_TOKEN_66 = 66; //"++"
    int t_TOKEN_67 = 67; //"--"
    int t_TOKEN_68 = 68; //"="

}
