package gals;

import java.util.ArrayList;
import java.util.Stack;

public class Semantico implements Constants {
    ArrayList<Simbolo> tabelaSimbolos;
    Stack<Integer> pilhaExpressoes;
    private Stack<Integer> pilhaEscopos;
    String tipo;
    int contadorEscopo = 0;
    int resultExp = -1;
    int resultAtrib = -1;
    int tipo1 = -1;
    int tipo2 = -1;
    int operacao = -1;
    int tp_id = -1;
    String auxOperacao = "";
    boolean verificaInicializada = false;
    boolean verificaDeclarada = false;

    // Codigo abaixo para o BIP, codigo acima mantido so por garantia
    private String codigoSecaoData = ".data\n";
    private String codigoSecaoText = ".text\n";
    String nome_variavel_simples;
    String nome_variavel_simples_atribuicao;
    String nome_variavel_vetor_atribuicao;
    String nome_variavel_vetor_expressao;
    String nome_variavel_vetor_print;
    String nome_variavel_vetor_scan;
    String valor_variavel_simples;
    String nome_vetor;
    String quantidade_posicoes_vetor;
    boolean lendoSecaoData = true;
    boolean flagInicializada = false;
    boolean flagUsada = false;
    boolean flagParametro = false;
    int posicaoParametro = 0;
    String avisosSemanticos = "";
    ArrayList<Temporario> listaTemporarios;
    String textoDeclaracaoVetor = "";
    int indiceAtribuicaoVetor = 0;
    int indicePrimeiroOperador = 0;
    Temporario temp1;
    Temporario temp2;
    Boolean flagOperador = false;
    Boolean flagOperadorAnterior = null;
    String operador;
    String operadorAnterior = null;

    // Variaveis geracao2
    String operadorCondicional = "";
    Temporario tempCond;
    Temporario tempCond2;
    Stack<String> pilhaRotulos;
    Integer contadorRotulo = 0;
    Boolean flagNãoGeraAssembly = false;
    String incremento = "";
    String nomeFuncao = "";
    String nomeParametro = "";
    int contadorParametro = 0;
    String nomeFuncaoChamada = "";
    String nomeParametroChamada = "";

    public Semantico() {
        tabelaSimbolos = new java.util.ArrayList<Simbolo>();
        pilhaEscopos = new Stack<Integer>();
        pilhaEscopos.push(contadorEscopo); // Escopo global começa no índice 0
        pilhaExpressoes = new Stack<Integer>();
        listaTemporarios = new ArrayList<Temporario>();
        pilhaRotulos = new Stack<String>();
    }

    public Boolean existeMain(){
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals("main") && tabelaSimbolos.get(i).getFuncao()) {
                return true; // Retorna true se a função main for encontrada
            }
        }
        return false; // Retorna false se a função main não for encontrada
    }

    private String retornaPrefixo(String nomeVariavel) {
        // Verifica se a variável é um vetor ou uma variável simples
        if(!pilhaEscopos.isEmpty()) {
            Stack<Integer> copiaPilhaEscopos = (Stack<Integer>) pilhaEscopos.clone();
            while(!copiaPilhaEscopos.isEmpty()) {
                int escopoAtual = copiaPilhaEscopos.pop(); // Pega o escopo atual
                for (int i = 0; i < tabelaSimbolos.size(); i++) {
                    if (tabelaSimbolos.get(i).getId().equals(nomeVariavel) && tabelaSimbolos.get(i).getEscopo() == escopoAtual) {
                        return tabelaSimbolos.get(i).getNomeFuncao() + tabelaSimbolos.get(i).getEscopo() + "_";
                    }
                }
            }
        }
        return null; // Retorna null se não encontrar a variável
    }

    private String retornaPrefixoParametro(String nomeParametro, String nomeFuncao) {
        // Verifica se o parâmetro pertence à função especificada
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nomeParametro) && tabelaSimbolos.get(i).getNomeFuncao().equals(nomeFuncao) && tabelaSimbolos.get(i).getParametro()) {
                return tabelaSimbolos.get(i).getNomeFuncao() + tabelaSimbolos.get(i).getEscopo() + "_";
            }
        }
        return null; // Retorna null se não encontrar o parâmetro

    }

    private String pegaParametroFuncao(String nomeFuncao, int contadorParametro) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getNomeFuncao().equals(nomeFuncao) && !tabelaSimbolos.get(i).getFuncao()) {
                if (tabelaSimbolos.get(i).getParametro() && tabelaSimbolos.get(i).getPosicao() == contadorParametro) {
                    return tabelaSimbolos.get(i).getId();
                }
            }
        }
        return null; // Retorna null se não encontrar o parâmetro
    }

    private int buscaMaiorValorParametro(String nomeFuncao){
        int maiorValor = -1;
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getNomeFuncao().equals(nomeFuncao) && tabelaSimbolos.get(i).getParametro()) {
                if (tabelaSimbolos.get(i).getPosicao() > maiorValor) {
                    maiorValor = tabelaSimbolos.get(i).getPosicao();
                }
            }
        }
        return maiorValor; // Retorna o maior valor encontrado ou -1 se não houver parâmetros
    }

    private void geraRotulo() {
        String rotulo = "R" + contadorRotulo++;
        pilhaRotulos.push(rotulo);
    }

    public String getRotulo() {
        if (!pilhaRotulos.isEmpty()) {
            return pilhaRotulos.peek(); // Retorna o último rótulo adicionado
        }
        return null; // Retorna null se não houver rótulos na pilha
    }

    public String getRotuloAndPop() {
        if (!pilhaRotulos.isEmpty()) {
            return pilhaRotulos.pop(); // Retorna o último rótulo adicionado
        }
        return null; // Retorna null se não houver rótulos na pilha
    }

    private void guardarOperador(){
        if(flagOperadorAnterior == null) {
            flagOperadorAnterior = flagOperador;
            flagOperador = false;
        }
        if(operadorAnterior == null){
            operadorAnterior = operador;
        }
    }

    private void recuperaOperador(){
        if(flagOperadorAnterior != null){
            flagOperador = flagOperadorAnterior;
            flagOperadorAnterior = null;
        }
        if(operadorAnterior != null){
            operador = operadorAnterior;
            operadorAnterior = null;
        }
    }

    private int getIndiceTemp(Temporario temp) {
        for (int i = 0; i < listaTemporarios.size(); i++) {
            if (listaTemporarios.get(i).getNome().equals(temp.getNome())) {
                return i; // Retorna o índice do temporário
            }
        }
        return -1; // Retorna -1 se não encontrar o temporário
    }

    private Temporario getTemp(){
        Temporario temp = null;
        for (int i = 0; i < listaTemporarios.size(); i++) {
            if (listaTemporarios.get(i).livre) {
                temp = listaTemporarios.get(i);
                temp.setLivre(false);
                return temp;
            }
        }
        // Se não encontrar um temporário livre, cria um novo
        temp = new Temporario("temp" + listaTemporarios.size());
        temp.setLivre(false);
        listaTemporarios.add(temp);
        return temp;
    }

    public String getAvisosSemanticos() {
        return this.avisosSemanticos;
    }

    private void avisosSemanticos(String aviso){
        this.avisosSemanticos += aviso + "\n";
    }

    public String compilarAssembly(){
        return codigoSecaoData + "\n" + codigoSecaoText;
    }

    public void geraTempData(){
        for (Temporario temp : listaTemporarios) {
            codigoSecaoData += temp.getNome() + ": 0\n"; // Cada temporário é inicializado com 0
        }
    }

    public void geraCodAssemblyText(String nome, String valor) {
        if(flagNãoGeraAssembly){
            incremento += "  " + nome + " " + valor + "\n";
        } else{
            codigoSecaoText += "  " + nome + " " + valor + "\n";
        }
    }

    public void geraCodAssemblyText(String nome) {
        codigoSecaoText += "\n" + nome + ":\n";
    }

    public void geraCodAssemblyTextIncremento(String nome) {
        codigoSecaoText += nome;
    }

    public void geraCodAssemblyData(String nome){
        if (nome != null) {
            codigoSecaoData += nome + ": 0\n";
        }
    }

    public void geraCodAssemblyDataVetor(int tamanho, String nome) {
        for (int i = 0; i < tamanho; i++) {
            if(i == tamanho - 1) {
                textoDeclaracaoVetor += "0"; // Não adiciona vírgula no último elemento
            } else {
                textoDeclaracaoVetor += "0, "; // Adiciona vírgula entre os elementos
            }
        }
        if (nome != null) {
            codigoSecaoData += nome + ": " + textoDeclaracaoVetor + "\n"; // Cada inteiro ocupa 4 bytes
        }
    }

    public ArrayList<Simbolo> getTabelaSimbolos() {
        return this.tabelaSimbolos;
    }

    public void abreEscopo(int contadorEscopo) {
        // Adiciona o índice atual da tabela como início do novo escopo
        pilhaEscopos.push(contadorEscopo);
    }

    public void fechaEscopo() {
        if (!pilhaEscopos.isEmpty()) {
            pilhaEscopos.pop(); // Remove o escopo atual da pilha
        }
    }

    public boolean verificaUnicidade(String nome) {
        int auxEscopoAtual = 0;
        // Cria uma cópia da pilha de escopos para preservar o estado original
        if (!pilhaEscopos.isEmpty()) {
            Stack<Integer> copiaPilhaEscopos = (Stack<Integer>) pilhaEscopos.clone();

            while (true) {
                if (!copiaPilhaEscopos.isEmpty()) {
                    auxEscopoAtual = copiaPilhaEscopos.pop(); // Pega o escopo atual
                    for (int i = 0; i < tabelaSimbolos.size(); i++) {
                        if (tabelaSimbolos.get(i).getEscopo() == auxEscopoAtual) {

                            if (tabelaSimbolos.get(i).getId().equals(nome)) {
                                // Se o nome já existe no escopo atual, retorna false
                                return false;
                            }
                        } else {
                            continue;
                        }
                    }
                } else {
                    break; // Se não houver mais escopos, sai do loop
                }
            }
        } else {
            return true; // Se a pilha de escopos estiver vazia, retorna true
        }

        return true; // Retorna true se o símbolo não foi encontrado no escopo atual
    }

    public String buscaTipoVariavel(String nome) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome) && !tabelaSimbolos.get(i).getFuncao()) {
                return tabelaSimbolos.get(i).getTipo();
            }
        }
        return ""; // Retorna null se a variável não for encontrada
    }

    public String buscaTipoFuncao(String nome) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome) && tabelaSimbolos.get(i).getFuncao()) {
                return tabelaSimbolos.get(i).getTipo();
            }
        }
        return ""; // Retorna null se a variável não for encontrada
    }

    public boolean buscaVerificaInicializada(String nome) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome)) {
                verificaInicializada = tabelaSimbolos.get(i).getInicializada();
                return verificaInicializada;
            }
        }
        return false; // Retorna false se a variável não for encontrada
    }

    public void defineUsada(String nome) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome)) {
                tabelaSimbolos.get(i).setUsada(true);
            }
        }
    }

    public void defineInicializada(String nome) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome)) {
                tabelaSimbolos.get(i).setInicializada(true);
            }
        }
    }

    //funcoes para geracao codigo 1
    private boolean verificaDeclarada(String nome){
        if(!pilhaEscopos.isEmpty()) {
            Stack<Integer> copiaPilhaEscopos = (Stack<Integer>) pilhaEscopos.clone();
            while(!copiaPilhaEscopos.isEmpty()) {
                int escopoAtual = copiaPilhaEscopos.pop(); // Pega o escopo atual
                for (int i = 0; i < tabelaSimbolos.size(); i++) { //PAREI AQUI, FALTA VERIFICAR O CODIGO ASSEMBLY GERADO PARA FUNCOES E TALVEZ OBRIGAR A TER UM RETORNO EM UMA FUNCAO COM TIPO INT
                    if (tabelaSimbolos.get(i).getEscopo() == escopoAtual) {
                        if (tabelaSimbolos.get(i).getId().equals(nome)) {
                            return true; // Se a variável for encontrada, sai do método
                        }
                    }
                }
            }
        }
        // Se a variável não for encontrada, lança uma exceção
        return false;
    }

    private boolean verificaInicializada(String nome){
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getId().equals(nome)) {
                if (tabelaSimbolos.get(i).getInicializada()) {
                    return true;
                }
            }
        }
        return false;
    }

    public void varreduraTabelaSimbolos() {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (!tabelaSimbolos.get(i).getUsada() && !tabelaSimbolos.get(i).getFuncao()) {
                avisosSemanticos("Aviso: A variável " + tabelaSimbolos.get(i).getId() + " não foi usada.");
            }
        }
    }

    boolean verificaUnicidadeInsercaoTabela(int escopoAtual, String nome, Boolean funcao) {
        for (int i = 0; i < tabelaSimbolos.size(); i++) {
            if (tabelaSimbolos.get(i).getEscopo() == escopoAtual) {
                if (tabelaSimbolos.get(i).getId().equals(nome) && tabelaSimbolos.get(i).getFuncao() == funcao) {
                    // Se o nome já existe no escopo atual, retorna false
                    return false;
                }
            } else {
                continue;
            }
        }
        return true; // Retorna true se o símbolo não foi encontrado no escopo atual
    }

    // nome, tipo, inicializada, usada, escopo, parametro, posicao, vetor,
    // referencia, funcao
    public void insere_tabela(String nome, String tipo, boolean inicializada, boolean usada, int escopo,
            boolean parametro,
            int posicao, boolean vetor, boolean referencia, boolean funcao, String nomeFuncao) throws SemanticError {
        // Verifica a unicidade da variável no escopo atual
        boolean teste;
        teste = verificaUnicidadeInsercaoTabela(pilhaEscopos.peek(), nome, funcao);
        if (!teste) {
            throw new SemanticError("Variável/Vetor/Função já declarada no escopo");
        }
        // Adiciona a variável à tabela de símbolos
        Simbolo novoSimbolo = new Simbolo(nome, tipo, inicializada, usada, escopo, parametro, posicao, vetor,
                referencia, funcao, nomeFuncao);
        tabelaSimbolos.add(novoSimbolo);
    }

    public void executeAction(int action, Token token) throws SemanticError {
        System.out.println("Ação #" + action + ", Token: " + token);

        switch (action) {
            case 1: // Pega o nome da variável simples
                nome_variavel_simples = token.getLexeme();
                // nome, tipo, inicializada, usada, escopo, parametro, posicao, vetor,
                // referencia, funcao
                insere_tabela(nome_variavel_simples, "int", false, false, pilhaEscopos.peek(), false, 0, false, false, false, nomeFuncao);
                geraCodAssemblyData(retornaPrefixo(nome_variavel_simples)+nome_variavel_simples);
                valor_variavel_simples = null;
                break;
            case 2: // Pega o nome do vetor
                nome_vetor = token.getLexeme();
                // nome, tipo, inicializada, usada, escopo, parametro, posicao, vetor,
                // referencia, funcao
                insere_tabela(nome_vetor, "int", true, false, pilhaEscopos.peek(), false, 0, true, false, false, nomeFuncao);
                break;
            case 3: // Gera o codigo assembly para declarar a variável simples
                // nao tem nada aqui
                break;
            case 4: // Pega operador da expressão
                flagOperador = true;
                operador = token.getLexeme();
                break;
            case 5: // Gera o código assembly para a operação com variavel simples
                if(!verificaDeclarada(token.getLexeme())){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    if(!verificaInicializada(token.getLexeme())){
                        // Se não foi inicializada, lança uma exceção
                        avisosSemanticos("Aviso : Variável " + token.getLexeme() + " não inicializada.");
                    }
                    defineUsada(token.getLexeme());
                }
                if(!flagOperador){
                    geraCodAssemblyText("LD", retornaPrefixo(token.getLexeme())+token.getLexeme());
                } else{
                    if (operador.equals("+")) {
                        geraCodAssemblyText("ADD", retornaPrefixo(token.getLexeme())+token.getLexeme());
                    }
                    if (operador.equals("-")) {
                        geraCodAssemblyText("SUB", retornaPrefixo(token.getLexeme())+token.getLexeme());                        
                    }
                }
                break;
            case 6: // Gera código assembly para a operação com valores imediatos(INT)
                if (!flagOperador) {
                    geraCodAssemblyText("LDI", token.getLexeme());
                } else {
                    if (operador.equals("+")) {
                        geraCodAssemblyText("ADDI", token.getLexeme());
                    }
                    if (operador.equals("-")) {
                        geraCodAssemblyText("SUBI", token.getLexeme());
                    }
                    if (operador.equals(">>")){
                        geraCodAssemblyText("SRL", token.getLexeme());
                    }
                    if (operador.equals("<<")){
                        geraCodAssemblyText("SLL", token.getLexeme());
                    }
                }
                break;
            case 7: // Pega o nome da variavel simples para atribuição
                nome_variavel_simples_atribuicao = token.getLexeme();
                
                if(!verificaDeclarada(nome_variavel_simples_atribuicao)) {
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + nome_variavel_simples_atribuicao);
                }
                break;
            case 8: // Gera o código assembly para atribuição de variável simples(Faz o STO - Storage na memoria)
        
                geraCodAssemblyText("STO", retornaPrefixo(nome_variavel_simples_atribuicao)+nome_variavel_simples_atribuicao);
                
                flagOperador = false; // Reseta o flag do operador
                defineInicializada(nome_variavel_simples);
                break;
            case 9: // Pega a entrada de dados
                if(!verificaDeclarada(token.getLexeme())){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    defineUsada(token.getLexeme());
                    defineInicializada(token.getLexeme());
                }
                geraCodAssemblyText("LD", "$in_port");
                geraCodAssemblyText("STO", retornaPrefixo(token.getLexeme())+token.getLexeme());
                break;
            case 10: // Pega a quantidade de posicoes do vetor
                quantidade_posicoes_vetor = token.getLexeme();
                if(Integer.parseInt(quantidade_posicoes_vetor) <= 0) {
                    throw new SemanticError("Tamanho do vetor deve ser maior que zero.");
                }
                geraCodAssemblyDataVetor(Integer.parseInt(quantidade_posicoes_vetor), retornaPrefixo(nome_vetor)+nome_vetor);
                textoDeclaracaoVetor = ""; // Reseta o texto de declaração do vetor
                break;
            case 11: 
                // nao tem nada aqui
                break;
            case 12: // Pega o nome da variavel simples de declaracao com expressao
                nome_variavel_simples = token.getLexeme();
                // nome, tipo, inicializada, usada, escopo, parametro, posicao, vetor,
                // referencia, funcao
                insere_tabela(nome_variavel_simples, "int", true, false, pilhaEscopos.peek(), false, 0, false, false, false, nomeFuncao);
                geraCodAssemblyData(retornaPrefixo(nome_variavel_simples)+nome_variavel_simples);
                break;
            case 13: // Pega o resultado da expressao de declaracao e atribui a variavel simples declarada
                geraCodAssemblyText("STO", retornaPrefixo(nome_variavel_simples)+nome_variavel_simples);
                flagOperador = false; // Reseta o flag do operador
                break;
            case 14: 
                //nao tem nada aqui
                break;
            case 15: // Pega o nome do vetor para usar em expressoes
                nome_variavel_vetor_expressao = token.getLexeme();
                
                if(!verificaDeclarada(token.getLexeme())){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    defineUsada(token.getLexeme());
                }
                
                if(flagOperador){
                    temp1 = getTemp();
                    indicePrimeiroOperador = getIndiceTemp(temp1);
                    geraCodAssemblyText("STO", temp1.getNome());
                }
                guardarOperador();
                break;
            case 16:
                recuperaOperador();
                geraCodAssemblyText("STO", "$indr");
                geraCodAssemblyText("LDV", retornaPrefixo(nome_variavel_vetor_expressao)+nome_variavel_vetor_expressao);
                if(flagOperador){
                    temp2 = getTemp();
                    geraCodAssemblyText("STO", temp2.getNome());
                    geraCodAssemblyText("LD", temp1.getNome());
                    temp1.setLivre(true);
                    if (operador.equals("+")) {
                        geraCodAssemblyText("ADD", temp2.getNome());
                    }
                    if (operador.equals("-")) {
                        geraCodAssemblyText("SUB", temp2.getNome());                        
                    }
                    temp2.setLivre(true);
                }
                
                break;
            case 17: // Logica expressao dentro do indice de vetor na atribuição
                recuperaOperador();
                Temporario temp = getTemp();
                geraCodAssemblyText("STO", temp.getNome());
                indiceAtribuicaoVetor = getIndiceTemp(temp);
                break;
            case 18:
                Temporario tempResultado = getTemp();
                geraCodAssemblyText("STO", tempResultado.getNome());
                Temporario tempAtribuicao = listaTemporarios.get(indiceAtribuicaoVetor);
                geraCodAssemblyText("LD", tempAtribuicao.getNome());
                tempAtribuicao.setLivre(true); // Libera o temporário após uso
                geraCodAssemblyText("STO", "$indr");
                geraCodAssemblyText("LD", tempResultado.getNome());
                tempResultado.setLivre(true); // Libera o temporário após uso
                geraCodAssemblyText("STOV", retornaPrefixo(nome_variavel_vetor_atribuicao)+nome_variavel_vetor_atribuicao);
                flagOperador = false; // Reseta o flag do operador
                break;
            case 19: // Gera codigo assembly de print para inteiros
                geraCodAssemblyText("LDI", token.getLexeme());
                geraCodAssemblyText("STO", "$out_port");
                break;
            case 20: // Gera codigo assembly de print para variaveis simples
                if(!verificaDeclarada(token.getLexeme())){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    if(!verificaInicializada(token.getLexeme())){
                        // Se não foi inicializada, lança uma exceção
                        avisosSemanticos("Aviso : Variável " + token.getLexeme() + " não inicializada.");
                    }
                    defineUsada(token.getLexeme());
                }
                geraCodAssemblyText("LD", retornaPrefixo(token.getLexeme())+token.getLexeme());
                geraCodAssemblyText("STO", "$out_port");
                break;
            case 21: // Pega o nome do vetor que ira ser usado no print
                nome_variavel_vetor_print = token.getLexeme();
                
                if(!verificaDeclarada(nome_variavel_vetor_print)){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    defineUsada(token.getLexeme());
                }
                break;
            case 22: // Calcula o indice do vetor para o print e gera o código assembly do vetor para o print
                geraCodAssemblyText("STO", "$indr");
                geraCodAssemblyText("LDV", retornaPrefixo(nome_variavel_vetor_print)+nome_variavel_vetor_print);
                geraCodAssemblyText("STO", "$out_port");
                flagOperador = false; // Reseta o flag do operador
                break;
            case 23: // Pega o nome do vetor para scan
                nome_variavel_vetor_scan = token.getLexeme();
                if(!verificaDeclarada(nome_variavel_vetor_scan)){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                } else {
                    defineUsada(token.getLexeme());
                }  
                break;
            case 24: // Calcula o indice do vetor para o scan e gera o código assembly do vetor para o scan
                geraCodAssemblyText("STO", "$indr");
                geraCodAssemblyText("LD", "$in_port");
                geraCodAssemblyText("STOV", retornaPrefixo(nome_variavel_vetor_scan)+nome_variavel_vetor_scan);
                flagOperador = false; // Reseta o flag do operador
                break;
            case 25:
                nome_variavel_vetor_atribuicao = token.getLexeme();
                if(!verificaDeclarada(nome_variavel_vetor_atribuicao)){
                    // Se não foi declarada, lança uma exceção
                    throw new SemanticError("Variável não declarada: " + token.getLexeme());
                }
                guardarOperador();
                break;
            case 26: // Pega o operador da condição
                flagOperador = false;
                tempCond = getTemp();
                operadorCondicional = token.getLexeme();
                geraCodAssemblyText("STO", tempCond.getNome());
                break;
            case 27: // Pega o operador da condição
                tempCond2 = getTemp();
                geraCodAssemblyText("STO", tempCond2.getNome());
                geraCodAssemblyText("LD", tempCond.getNome());
                geraCodAssemblyText("SUB", tempCond2.getNome());
                tempCond.setLivre(true); // Libera o temporário após uso
                tempCond2.setLivre(true); // Libera o temporário após uso
                break;
            case 28: // Atibui string vazia ao operador condicional
                operadorCondicional = "";
                geraRotulo();
                contadorEscopo++;
                abreEscopo(contadorEscopo);
                break;
            case 29: // Cria novo rotulo e gera o código assembly para a condição
                String rotulo = getRotulo();
                if (rotulo != null) {
                    if(operadorCondicional.equals("")){
                        throw new SemanticError("Erro: Operação não suportada.");
                    }
                    if (operadorCondicional.equals("==")) {
                        geraCodAssemblyText("BNE", rotulo);
                    } else if (operadorCondicional.equals("!=")) {
                        geraCodAssemblyText("BEQ", rotulo);
                    } else if (operadorCondicional.equals("<")) {
                        geraCodAssemblyText("BGE", rotulo);
                    } else if (operadorCondicional.equals("<=")) {
                        geraCodAssemblyText("BGT", rotulo);
                    } else if (operadorCondicional.equals(">")) {
                        geraCodAssemblyText("BLE", rotulo);
                    } else if (operadorCondicional.equals(">=")) {
                        geraCodAssemblyText("BLT", rotulo);
                    }
                } else {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                break;
            case 30: // Errei fui muleke
                break;
            case 31: 
                String rotuloFimIfSimples = getRotuloAndPop();
                if (rotuloFimIfSimples != null) {
                    geraCodAssemblyText(rotuloFimIfSimples);
                } else {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                fechaEscopo(); // Fecha o escopo do if
                break;
            case 32:
                String rotuloIf = getRotuloAndPop();
                if (rotuloIf == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraRotulo();
                String rotuloElse = pilhaRotulos.peek();
                geraCodAssemblyText("JMP", rotuloElse);
                geraCodAssemblyText(rotuloIf);
                fechaEscopo(); // Fecha o escopo do if
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para o else
                break;
            case 33:
                String rotuloFimElse = getRotuloAndPop();
                if (rotuloFimElse != null) {
                    geraCodAssemblyText(rotuloFimElse);
                } else {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                fechaEscopo(); // Fecha o escopo do else
                break;
            case 34: // cria rotulo while
                geraRotulo();
                String rotuloWhile = pilhaRotulos.peek();
                if(rotuloWhile == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyText(rotuloWhile);
                geraRotulo();
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para o while
                break;
            case 35: // gera rotulo fim while
                String rotuloFimWhile = getRotuloAndPop();
                if( rotuloFimWhile == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                String rotuloInicioWhile = getRotuloAndPop();
                if(rotuloInicioWhile == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyText("JMP", rotuloInicioWhile);
                geraCodAssemblyText(rotuloFimWhile);
                fechaEscopo(); // Fecha o escopo do while
                break;
            case 36: // gera rotulo do while
                geraRotulo();
                String rotuloDoWhile = pilhaRotulos.peek();
                if(rotuloDoWhile == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyText(rotuloDoWhile);
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para o do While
                break;
            case 37:
                String rotuloBranch = getRotuloAndPop();
                if (rotuloBranch != null) {
                    if(operadorCondicional.equals("")){
                        throw new SemanticError("Erro: Operação não suportada.");
                    }
                    if (operadorCondicional.equals("==")) {
                        geraCodAssemblyText("BEQ", rotuloBranch);
                    } else if (operadorCondicional.equals("!=")) {
                        geraCodAssemblyText("BNE", rotuloBranch);
                    } else if (operadorCondicional.equals("<")) {
                        geraCodAssemblyText("BLT", rotuloBranch);
                    } else if (operadorCondicional.equals("<=")) {
                        geraCodAssemblyText("BLE", rotuloBranch);
                    } else if (operadorCondicional.equals(">")) {
                        geraCodAssemblyText("BGT", rotuloBranch);
                    } else if (operadorCondicional.equals(">=")) {
                        geraCodAssemblyText("BGE", rotuloBranch);
                    }
                } else {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                fechaEscopo(); // Fecha o escopo do While
                break;
            case 38: // gera rotulo for
                geraRotulo();
                String rotuloFor = pilhaRotulos.peek();
                if(rotuloFor == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyText(rotuloFor);
                geraRotulo(); // Cria um novo rótulo para o final do for
                break;
            case 39: // gera pilha atribuicao assembly
                flagNãoGeraAssembly = false; // Reseta o flag para gerar assembly
                pilhaRotulos.push(incremento); // Adiciona o incremento à pilha de rótulos
                break;
            case 40: // gera assembly incremento e gerar rotulos
                String incrementosString = getRotuloAndPop();
                if (incrementosString == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyTextIncremento(incrementosString);
                String rotuloBranchFor = getRotuloAndPop();
                if (rotuloBranchFor == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                String rotuloJumpFor = getRotuloAndPop();
                if (rotuloJumpFor == null) {
                    throw new SemanticError("Erro: Pilha de rótulos está vazia.");
                }
                geraCodAssemblyText("JMP", rotuloJumpFor);
                geraCodAssemblyText(rotuloBranchFor);
                fechaEscopo(); // Fecha o escopo do for
                break;
            case 41:
                flagNãoGeraAssembly = true;
                incremento = "";
                break;
            case 42: // Pega o nome da função com tipo
                nomeFuncao = token.getLexeme();
                insere_tabela(nomeFuncao, "int", true, false, pilhaEscopos.peek(), false, 0, false, false, true, nomeFuncao);
                geraCodAssemblyText("_"+nomeFuncao);
                contadorParametro = 0; // Reseta o contador de parâmetros
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para a função
                break;
            case 43: // Pega o nome do parametro e define o contador de parametros
                nomeParametro = token.getLexeme();
                insere_tabela(nomeParametro, "int", true, false, pilhaEscopos.peek(), true, contadorParametro, false, false, false, nomeFuncao);
                contadorParametro++;
                geraCodAssemblyData(retornaPrefixo(nomeParametro)+nomeParametro);
                break;
            case 44:
                // nao faz nada aqui
                break;
            case 45: // gera return da funcao
                if(nomeFuncao.equals("main")){
                    geraCodAssemblyText("HLT", "0");
                }else{
                    geraCodAssemblyText("RETURN", "0");
                }
                nomeFuncao = ""; // Reseta o nome da função
                fechaEscopo(); // Fecha o escopo da função
                break;
            case 46: // Pega o nome da função vazia
                nomeFuncao = token.getLexeme();
                insere_tabela(nomeFuncao, "void", true, false, pilhaEscopos.peek(), false, 0, false, false, true, nomeFuncao);
                geraCodAssemblyText("_"+nomeFuncao);
                contadorParametro = 0; // Reseta o contador de parâmetros
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para a função
                break;
            case 47: // pega o nome da funcao dentro de atribuicao
                nomeFuncaoChamada = token.getLexeme();
                if(!verificaDeclarada(nomeFuncaoChamada)){
                    throw new SemanticError("Função não declarada: " + nomeFuncaoChamada);
                }
                contadorParametro = 0;
                break;
            case 48: // gera o codigo assembly para chamada de função
                if((buscaMaiorValorParametro(nomeFuncaoChamada)+1) > (contadorParametro)){
                    throw new SemanticError("Função " + nomeFuncaoChamada + " espera " + (buscaMaiorValorParametro(nomeFuncaoChamada)+1) + " parâmetros, mas recebeu " + contadorParametro + ".");
                }
                geraCodAssemblyText("CALL", "_" + nomeFuncaoChamada);
                break;
            case 49:
                nomeParametroChamada = pegaParametroFuncao(nomeFuncaoChamada, contadorParametro);
                if(nomeParametroChamada == null) {
                    throw new SemanticError("Função " + nomeFuncaoChamada + " espera " + (buscaMaiorValorParametro(nomeFuncaoChamada)+1) + " parâmetros, mas recebeu " + (contadorParametro+1) + ".");
                }
                geraCodAssemblyText("STO", retornaPrefixoParametro(nomeParametroChamada, nomeFuncaoChamada) + nomeParametroChamada);
                contadorParametro++;
                break;
            case 50:
                contadorEscopo++;
                abreEscopo(contadorEscopo); // Abre um novo escopo para FOR
                break;
            case 51:
                if(buscaTipoFuncao(nomeFuncaoChamada).equals("void")){
                    throw new SemanticError("Função " + nomeFuncaoChamada + " não retorna valor.");
                }
                break;
            default:
                break;
        }
    }
}
