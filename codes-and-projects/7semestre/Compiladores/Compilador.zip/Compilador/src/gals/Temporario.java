package gals;

public class Temporario {
    String nome;
    boolean livre;

    public Temporario(String nome) {
        this.nome = nome;
        this.livre = true;
    }
    public String getNome() {
        return nome;
    }
    public void setLivre(boolean livre) {
        this.livre = livre;
    }
}
