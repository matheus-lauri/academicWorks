package gals;

import java.util.ArrayList;

public class Funcao {
    private String nome;
    private ArrayList<String> parametros;

    public Funcao(String nome, ArrayList<String> parametros) {
        this.nome = nome;
        this.parametros = parametros;
    }
    public String getNome() {
        return nome;
    }
    public ArrayList<String> getParametros() {
        return parametros;
    }
}
