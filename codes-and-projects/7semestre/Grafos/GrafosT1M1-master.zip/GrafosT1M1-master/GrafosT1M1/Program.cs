﻿using GrafosT1M1;
internal class Program
{
    private static void Main(string[] args)
    {
        Controle controle = new Controle();
        controle.Inicio();
    }
}