﻿using GrafosT5M3;
using System;
internal class Program
{
    private static void Main(string[] args)
    {
        GrafoMatriz grafoM = null;
        GrafoLista grafoL = null;

        //LeitorGrafo leitor = new LeitorGrafo(".\\..\\..\\..\\grafo.txt");

        LeitorGrafo leitor = new LeitorGrafo(".\\..\\..\\..\\grafo2.txt");


        int origem = 0;

        //Area para grafo de Matriz

        leitor.GeraGrafo(ref grafoM);

        grafoM.ImprimeGrafo(); // <-- Recomendado comentar em grafos extensos

        grafoM.ImprimeResultadoArvoreGeradora(grafoM.ExecutaPrim(), 0);

        Console.WriteLine();

        grafoM.ImprimeResultadoArvoreGeradora(grafoM.ExecutaKruskal(), 1);



        Console.WriteLine("\n\n\n\n");



        //Area para grafo de Matriz

        leitor.GeraGrafo(ref grafoL);

        grafoL.ImprimeGrafo(); // <-- Recomendado comentar em grafos extensos

        grafoL.ImprimeResultadoArvoreGeradora(grafoL.ExecutaPrim(), 0);

        Console.WriteLine();

        grafoL.ImprimeResultadoArvoreGeradora(grafoL.ExecutaKruskal(), 1);
    }


}