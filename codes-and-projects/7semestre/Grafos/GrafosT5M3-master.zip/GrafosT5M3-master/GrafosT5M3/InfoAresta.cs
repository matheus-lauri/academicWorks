﻿using System;

namespace GrafosT5M3
{
    public class InfoAresta
    {
        public int Origem {  get; set; }
        public int Destino { get; set; }
        public float Peso { get; set; }
        public InfoAresta(int origem, int destino, float peso)
        {
            Origem = origem;
            Destino = destino;
            Peso = peso;
        }
    }
}

