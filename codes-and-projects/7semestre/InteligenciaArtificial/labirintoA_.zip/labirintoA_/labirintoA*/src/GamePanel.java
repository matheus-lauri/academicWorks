import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.awt.image.*;
import javax.imageio.ImageIO;

import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.HashSet;
import java.util.ArrayList;

//CÓDIGO MODIFICADO PELO GRUPO: MATHEUS BARON LAURITZEN, GABRIEL BÓSIO E GUSTAVO BARON LAURITZEN
public class GamePanel extends Canvas implements Runnable
{
private static final int PWIDTH = 960;
private static final int PHEIGHT = 800;
private Thread animator;
private boolean running = false;
private boolean gameOver = false;
private Color caminhoCor = Color.RED;
private int currentPathIndex = 0;
private double agentX, agentY;
private double speed = 2.0;
<<<<<<< HEAD

=======
HashSet<Integer> closedSet;
>>>>>>> bc1e586 (Atualização de abertura de Nodos)

int FPS,SFPS;
int fpscount;

public static Random rnd = new Random();

//BufferedImage imagemcharsets;

boolean LEFT, RIGHT,UP,DOWN;

public static int mousex,mousey;

public static ArrayList<Agente> listadeagentes = new ArrayList<Agente>();

Mapa_Grid mapa;

double posx,posy;

MeuAgente meuHeroi = null;

//TODO ESSE È O RESULTADO
int caminho[] = null;

float zoom = 1;

int ntileW = 60;
int ntileH = 50;

Font f = new Font("", Font.BOLD, 20);

public GamePanel()
{

	setBackground(Color.white);
	setPreferredSize( new Dimension(PWIDTH, PHEIGHT));

	// create game components
	setFocusable(true);

	requestFocus(); // JPanel now receives key events


	// Adiciona um Key Listner
	addKeyListener( new KeyAdapter() {
		public void keyPressed(KeyEvent e)
			{
				int keyCode = e.getKeyCode();

				if(keyCode == KeyEvent.VK_LEFT){
					LEFT = true;
				}
				if(keyCode == KeyEvent.VK_RIGHT){
					RIGHT = true;
				}
				if(keyCode == KeyEvent.VK_UP){
					UP = true;
				}
				if(keyCode == KeyEvent.VK_DOWN){
					DOWN = true;
				}
			}
		@Override
			public void keyReleased(KeyEvent e ) {
				int keyCode = e.getKeyCode();

				if(keyCode == KeyEvent.VK_LEFT){
					LEFT = false;
				}
				if(keyCode == KeyEvent.VK_RIGHT){
					RIGHT = false;
				}
				if(keyCode == KeyEvent.VK_UP){
					UP = false;
				}
				if(keyCode == KeyEvent.VK_DOWN){
					DOWN = false;
				}
			}
	});

	addMouseMotionListener(new MouseMotionListener() {

		@Override
		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub
			mousex = e.getX();
			mousey = e.getY();


		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			if(e.getButton()==3){
				int mousex = (int)((e.getX()+mapa.MapX)/zoom);
				int mousey = (int)((e.getY()+mapa.MapY)/zoom);

				int mx = mousex/16;
				int my = mousey/16;

				if(mx>mapa.Altura) {
					return;
				}
				if(my>mapa.Largura) {
					return;
				}

				mapa.mapa[my][mx] = 1;
			}
		}
	});

	addMouseListener(new MouseListener() {

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			//System.out.println(" "+arg0.getButton());
			int mousex = (int)((arg0.getX()+mapa.MapX)/zoom);
			int mousey = (int)((arg0.getY()+mapa.MapY)/zoom);

			//System.out.println(""+arg0.getX()+" "+mapa.MapX+" "+zoom);
			//System.out.println(""+mousex+" "+mousey);

			int mx = mousex/16;
			int my = mousey/16;

			if(mx>mapa.Altura) {
				return;
			}
			if(my>mapa.Largura) {
				return;
			}

			if(arg0.getButton()==3){


				if(mapa.mapa[my][mx]==0){
					mapa.mapa[my][mx] = 1;
				}else{
					mapa.mapa[my][mx] = 0;
				}
			}
			if (arg0.getButton() == 1) {
				if (mapa.mapa[my][mx] == 0) {
					caminho = null; // Reinicia o caminho
					long timeini = System.currentTimeMillis();

					// Executa o Algoritmo A*
					System.out.println("" + my + " " + mx);
					System.out.println("meuHeroi " + (int) (meuHeroi.X / 16) + " " + (int) (meuHeroi.Y / 16));
					boolean caminhoEncontrado = rodaAStar((int) (meuHeroi.X / 16), (int) (meuHeroi.Y / 16), mx, my);

					if (caminhoEncontrado && caminho.length > 0) {
						startMoving();
					} else {
						System.out.println("Nenhum caminho encontrado ou caminho bloqueado.");
					}

					long timefin = System.currentTimeMillis() - timeini;
					System.out.println("Tempo Final: " + timefin);
				} else {
					System.out.println("Caminho Final Bloqueado");
				}
			}

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}
	});

	addMouseWheelListener(new MouseWheelListener() {

		@Override
		public void mouseWheelMoved(MouseWheelEvent e) {
			//System.out.println("w "+e.getWheelRotation());
			if(e.getWheelRotation()>0) {
				zoom= zoom*1.1f;
			}else if(e.getWheelRotation()<0) {
				zoom= zoom*0.90f;
			}

			ntileW = (int)((960/zoom)/16)+1;
			ntileH = (int)((800/zoom)/16)+1;

			if(ntileW>=1000) {
				ntileW = 1000;
			}
			if(ntileH>=1000) {
				ntileH = 1000;
			}
			mapa.NumeroTilesX = ntileW;
			mapa.NumeroTilesY = ntileH;
		}
	});

	meuHeroi = new MeuAgente(10, 10, Color.blue);

	listadeagentes.add(meuHeroi);

	mousex = mousey = 0;

	mapa = new Mapa_Grid(100,100,ntileW, ntileH);
	mapa.loadmapfromimage("res/imagemlabirinto1000.png");

} // end of GamePanel()

//LinkedList<Nodo> nodosPercorridos = new LinkedList();
HashSet<Integer> nodosPercorridos = new HashSet<Integer>();
public boolean jaPassei(int nX,int nY) {
	return nodosPercorridos.contains(nX+nY*1000);
}
LinkedList<Nodo> pilhaprofundidade = new LinkedList();

	public boolean rodaAStar(int iniX, int iniY, int objX, int objY) {
		currentPathIndex = 0; // Reinicia o caminho

		// Limpa os nodos percorridos anteriormente
		nodosPercorridos.clear();

		// Fila de prioridade ordenada pelo valor f
		PriorityQueue<NodoAStar> openSet = new PriorityQueue<>(new Comparator<NodoAStar>() {
			@Override
			public int compare(NodoAStar n1, NodoAStar n2) {
				return Float.compare(n1.f, n2.f);
			}
		});

		HashSet<Integer> closedSet = new HashSet<>();

		// Inicializa o nodo inicial
		NodoAStar start = new NodoAStar(iniX, iniY);
		start.g = 0;
		start.h = start.calcularHeuristica(objX, objY);
		start.f = start.g + start.h;

		openSet.add(start);

		while (!openSet.isEmpty()) {
			NodoAStar atual = openSet.poll();

			// Verifica se chegou ao objetivo
			if (atual.x == objX && atual.y == objY) {
				// Reconstrói o caminho
				ArrayList<NodoAStar> pathList = new ArrayList<>();
				NodoAStar current = atual;
				while (current != null) {
					pathList.add(0, current);
					current = current.parent;
				}

				// Converte o caminho para o formato esperado
				caminho = new int[pathList.size() * 2];
				for (int i = 0; i < pathList.size(); i++) {
					caminho[i * 2] = pathList.get(i).x;
					caminho[i * 2 + 1] = pathList.get(i).y;
<<<<<<< HEAD
					nodosPercorridos.add(pathList.get(i).x + pathList.get(i).y * 1000);
=======
					//nodosPercorridos.add(pathList.get(i).x + pathList.get(i).y * 1000);
>>>>>>> bc1e586 (Atualização de abertura de Nodos)
				}
				return true;
			}

			closedSet.add(atual.x + atual.y * 1000);

			// Gera os vizinhos
			int[][] direcoes = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
			for (int[] dir : direcoes) {
				int novoX = atual.x + dir[0];
				int novoY = atual.y + dir[1];

				// Verifica limites do mapa
				if (novoX < 0 || novoX >= 1000 || novoY < 0 || novoY >= 1000) {
					continue;
				}

				// Verifica se é parede ou já foi visitado
				if (mapa.mapa[novoY][novoX] == 1 || closedSet.contains(novoX + novoY * 1000)) {
					continue;
				}

				float novoG = atual.g + 1; // Custo para mover para célula adjacente

				NodoAStar vizinho = new NodoAStar(novoX, novoY);
				vizinho.g = novoG;
				vizinho.h = vizinho.calcularHeuristica(objX, objY);
				vizinho.f = vizinho.g + vizinho.h;
				vizinho.parent = atual;

				// Adiciona à lista aberta se ainda não estiver lá
				if (!closedSet.contains(novoX + novoY * 1000)) {
					openSet.add(vizinho);
<<<<<<< HEAD
				}
=======
					nodosPercorridos.add(novoX + novoY * 1000);
				}

>>>>>>> bc1e586 (Atualização de abertura de Nodos)
			}
		}

		// Define caminho como vazio quando não há solução
		caminho = new int[0];
		return false; // Caminho não encontrado
	}

<<<<<<< HEAD

/*public boolean rodaBuscaProfundidade(int iniX,int iniY,int objX,int objY) {
	Nodo nodoAtivo = new Nodo(iniX, iniY);
	pilhaprofundidade.add(nodoAtivo);

	while(pilhaprofundidade.size()>0) {
		//System.out.println(""+nodoAtivo.x+" "+nodoAtivo.y+" | "+objX+" "+objY);

		if(nodoAtivo.x==objX&&nodoAtivo.y==objY) {
			caminho = new int[pilhaprofundidade.size()*2];
			int index = 0;
			for (Iterator iterator = pilhaprofundidade.iterator(); iterator.hasNext();) {
				Nodo n = (Nodo) iterator.next();
				caminho[index] = n.x;
				caminho[index+1] = n.y;
				index+=2;
			}
			return true;
		}

//		if(mapa.mapa[nodoAtivo.y][nodoAtivo.x]==1) {
//			pilhaprofundidade.removeLast();
//			nodoAtivo=pilhaprofundidade.getLast();
//			continue;
//		}

		synchronized (nodosPercorridos) {
			//nodosPercorridos.add(nodoAtivo);
			nodosPercorridos.add(nodoAtivo.x+nodoAtivo.y*1000);
		}

		//if(jaPassei(iniX,iniY)) {
		//	return false;
		//}/

		//synchronized (nodosPercorridos) {
		//	nodosPercorridos.add(new Nodo(iniX,iniY));
		//}


//		try {
//			Thread.sleep(10);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}

		Nodo t[] = new Nodo[4];
		t[0] = new Nodo(nodoAtivo.x, nodoAtivo.y+1);
		t[1] = new Nodo(nodoAtivo.x+1, nodoAtivo.y);
		t[2] = new Nodo(nodoAtivo.x, nodoAtivo.y-1);
		t[3] = new Nodo(nodoAtivo.x-1, nodoAtivo.y);

		boolean ok = false;
		for(int i = 0; i < 4; i++) {
			if(t[i].y<0||t[i].y>=1000||t[i].x<0||t[i].x>=1000) {
				continue;
			}
			if(mapa.mapa[t[i].y][t[i].x]==0&&jaPassei(t[i].x,t[i].y)==false) {
				pilhaprofundidade.add(t[i]);
				nodoAtivo=t[i];
				ok = true;
				break;
			}
		}

		if(ok) {
			continue;
		}

		pilhaprofundidade.removeLast();
		nodoAtivo=pilhaprofundidade.getLast();
	}

	return false;
}*/


//public boolean rodaBuscaProfundidadeRecursivo(int iniX,int iniY,int objX,int objY) {
//	System.out.println(""+iniX+" "+iniY+" | "+objX+" "+objY);
//
//	if(iniX==objX&&iniY==objY) {
//		return true;
//	}
//
//	if(mapa.mapa[iniY][iniX]==1) {
//		return false;
//	}
//
//	if(jaPassei(iniX,iniY)) {
//		return false;
//	}
//
//	synchronized (nodosPercorridos) {
//		nodosPercorridos.add(new Nodo(iniX,iniY));
//	}
//
//
//	try {
//		Thread.sleep(10);
//	} catch (InterruptedException e) {
//		e.printStackTrace();
//	}
//
//	if(rodaBuscaProfundidadeRecursivo(iniX,iniY+1,objX,objY)) {
//		return true;
//	}
//	if(rodaBuscaProfundidadeRecursivo(iniX+1,iniY,objX,objY)) {
//		return true;
//	}
//	if(rodaBuscaProfundidadeRecursivo(iniX,iniY-1,objX,objY)) {
//		return true;
//	}
//	if(rodaBuscaProfundidadeRecursivo(iniX-1,iniY,objX,objY)) {
//		return true;
//	}
//
//	return false;
//}



=======
>>>>>>> bc1e586 (Atualização de abertura de Nodos)
public void startGame()
// initialise and start the thread
{
	if (animator == null || !running) {
		animator = new Thread(this);
		animator.start();
	}
} // end of startGame()

public void stopGame()
// called by the user to stop execution
{ running = false; }


public void run()
/* Repeatedly update, render, sleep */
{
	running = true;

	long DifTime,TempoAnterior;

	int segundo = 0;
	DifTime = 0;
	TempoAnterior = System.currentTimeMillis();

	this.createBufferStrategy(2);
	BufferStrategy strategy = this.getBufferStrategy();

	while(running) {

		gameUpdate(DifTime); // game state is updated
		Graphics g = strategy.getDrawGraphics();
		gameRender((Graphics2D)g); // render to a buffer
		strategy.show();

		try {
			Thread.sleep(0); // sleep a bit
		}
		catch(InterruptedException ex){}

		DifTime = System.currentTimeMillis() - TempoAnterior;
		TempoAnterior = System.currentTimeMillis();

		if(segundo!=((int)(TempoAnterior/1000))){
			FPS = SFPS;
			SFPS = 1;
			segundo = ((int)(TempoAnterior/1000));
		}else{
			SFPS++;
		}

	}
System.exit(0); // so enclosing JFrame/JApplet exits
} // end of run()

	public void startMoving() {
		if (caminho != null && caminho.length >= 2) {
			currentPathIndex = 0; // Reseta o índice ao início do caminho
			agentX = caminho[0] * 16; // Define a posição inicial do agente (em pixels)
			agentY = caminho[1] * 16;
		}
	}

	private void updateAgentPosition() {
		if (caminho != null && currentPathIndex < caminho.length / 2) {
			int targetX = caminho[currentPathIndex * 2] * 16;
			int targetY = caminho[currentPathIndex * 2 + 1] * 16;

			double deltaX = targetX - meuHeroi.X;
			double deltaY = targetY - meuHeroi.Y;
			double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

			if (distance < speed) {
				meuHeroi.X = targetX;
				meuHeroi.Y = targetY;
				currentPathIndex++;
			} else {
				meuHeroi.X += (deltaX / distance) * speed;
				meuHeroi.Y += (deltaY / distance) * speed;
			}
		} else if (caminho != null && currentPathIndex >= caminho.length / 2) {
			System.out.println("Agente chegou ao destino final!");
		}
	}


	int timerfps = 0;
private void gameUpdate(long DiffTime)
{

	if(LEFT){
		posx-=1000*DiffTime/1000.0;
	}
	if(RIGHT){
		posx+=1000*DiffTime/1000.0;
	}
	if(UP){
		posy-=1000*DiffTime/1000.0;
	}
	if(DOWN){
		posy+=1000*DiffTime/1000.0;
	}

	if(posx>mapa.Largura*16) {
		posx=mapa.Largura*16;
	}
	if(posy>mapa.Altura*16) {
		posy=mapa.Altura*16;
	}
	if(posx<0) {
		posx=0;
	}
	if(posy<0) {
		posy=0;
	}

	mapa.Posiciona((int)posx,(int)posy);

	for(int i = 0;i < listadeagentes.size();i++){
		  listadeagentes.get(i).SimulaSe((int)DiffTime);
	}
	updateAgentPosition();

}

private void gameRender(Graphics2D dbg)
// draw the current frame to an image buffer
{
	// clear the background
	dbg.setColor(Color.white);
	dbg.fillRect (0, 0, PWIDTH, PHEIGHT);

	AffineTransform trans = dbg.getTransform();
	dbg.scale(zoom, zoom);

	try {
		mapa.DesenhaSe(dbg);
	}catch (Exception e) {
		System.out.println("Erro ao desenhar mapa");
	}

	for(int i = 0;i < listadeagentes.size();i++){
	  listadeagentes.get(i).DesenhaSe(dbg, mapa.MapX, mapa.MapY);
	}

<<<<<<< HEAD
	synchronized (nodosPercorridos) {
=======

>>>>>>> bc1e586 (Atualização de abertura de Nodos)
		for (Iterator iterator = nodosPercorridos.iterator(); iterator.hasNext();) {
			Integer nxy = (Integer) iterator.next();
			int px = nxy%1000;
			int py = (int)(nxy/1000);
<<<<<<< HEAD
			dbg.setColor(Color.GREEN);
			dbg.fillRect(px*16-mapa.MapX, py*16-mapa.MapY, 16, 16);
		}
	}

	if(caminho!=null){

=======
			dbg.setColor(Color.RED);
			dbg.fillRect(px*16-mapa.MapX, py*16-mapa.MapY, 16, 16);
		}


	if(caminho!=null){
>>>>>>> bc1e586 (Atualização de abertura de Nodos)
		try {
			if(caminho!=null){
				for(int i = 0; i < caminho.length/2;i++){
					int nx = caminho[i*2];
					int ny = caminho[i*2+1];

					dbg.setColor(Color.GREEN);
					dbg.fillRect(nx*16-mapa.MapX, ny*16-mapa.MapY, 16, 16);
				}
			}
		}catch (Exception e) {
		}
	}

	dbg.setTransform(trans);

	dbg.setFont(f);
	dbg.setColor(Color.BLUE);
	dbg.drawString("FPS: "+FPS, 10, 30);

	dbg.drawString("N: "+nodosPercorridos.size(), 100, 30);
	//System.out.println("left "+LEFT);

}

}

