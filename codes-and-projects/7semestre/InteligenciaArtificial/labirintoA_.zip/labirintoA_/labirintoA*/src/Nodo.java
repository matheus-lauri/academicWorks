
public class Nodo {
	int x;
	int y;
	public Nodo(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
}
