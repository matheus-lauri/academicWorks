//CÓDIGO MODIFICADO PELO GRUPO: MATHEUS BARON LAURITZEN, GABRIEL BÓSIO E GUSTAVO BARON LAURITZEN
class NodoAStar extends Nodo {
    public float g; // custo do caminho desde o início até este nodo
    public float h; // heurística (estimativa do custo até o objetivo)
    public float f; // f = g + h
    public NodoAStar parent; // nodo pai para reconstruir o caminho

    public NodoAStar(int x, int y) {
        super(x, y);
        this.g = 0;
        this.h = 0;
        this.f = 0;
        this.parent = null;
    }

<<<<<<< HEAD
    // Função heurística - distância de Manhattan
=======
    // Distância de Manhattan
>>>>>>> bc1e586 (Atualização de abertura de Nodos)
    public float calcularHeuristica(int objX, int objY) {
        return Math.abs(x - objX) + Math.abs(y - objY);
    }
}