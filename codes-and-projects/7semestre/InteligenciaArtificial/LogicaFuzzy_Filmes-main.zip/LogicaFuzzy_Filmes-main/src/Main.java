import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.text.SimpleDateFormat;

public class Main {
    public static void main(String[] args) {

        GrupoVariaveis grupoGenero = new GrupoVariaveis();
        grupoGenero.add(new VariavelFuzzy("Obra prima",50,80,100,100));
        grupoGenero.add(new VariavelFuzzy("Bom",40,60,75,90));
        grupoGenero.add(new VariavelFuzzy("Mediano",0,45,55,100));
        grupoGenero.add(new VariavelFuzzy("Ruim",10,25,40,60));
        grupoGenero.add(new VariavelFuzzy("Horrivel",0,0,20,50));

        GrupoVariaveis grupoTempoDuracao = new GrupoVariaveis();
        grupoTempoDuracao.add(new VariavelFuzzy("Muito curto",0,0, 600, 900));
        grupoTempoDuracao.add(new VariavelFuzzy("Ideal",850, 1100,1500,1800));
        grupoTempoDuracao.add(new VariavelFuzzy("Muito longo",1600,1900,4000,4000));

        GrupoVariaveis grupoOrcamento = new GrupoVariaveis();
        grupoOrcamento.add(new VariavelFuzzy("Micro orcamento", 0, 0, 12000000, 30000000));
        grupoOrcamento.add(new VariavelFuzzy("Baixo orcamento", 6000000, 20000000, 30000000, 40000000));
        grupoOrcamento.add(new VariavelFuzzy("Medio orcamento", 25000000, 50000000, 90000000, 120000000));
        grupoOrcamento.add(new VariavelFuzzy("Alto orcamento", 100000000, 150000000, 380000000, 380000000));

        GrupoVariaveis grupoEpoca = new GrupoVariaveis();
        grupoEpoca.add(new VariavelFuzzy("Novo ideal",2000,2005,2020,2025));
        grupoEpoca.add(new VariavelFuzzy("Velho mediano",1980,1980,1995,1995));
        grupoEpoca.add(new VariavelFuzzy("Muito velho",1900,1910,1980,1980));

        GrupoVariaveis grupoPopularidade = new GrupoVariaveis();
        grupoPopularidade.add(new VariavelFuzzy("Obscuro", 0, 0, 75, 150));
        grupoPopularidade.add(new VariavelFuzzy("Emergente", 100, 200, 300, 400));
        grupoPopularidade.add(new VariavelFuzzy("Viral", 250, 425, 600, 700));
        grupoPopularidade.add(new VariavelFuzzy("Fenomeno", 600, 750, 876, 876));

        try {
            BufferedReader bfr = new BufferedReader(new FileReader(new File("C:\\Estudos_Univali\\IA\\MoviesT1\\movie_dataset.csv")));

            String header = bfr.readLine();
            String splitheder[] = header.split(",");
            for (int i = 0; i < splitheder.length;i++) {
                System.out.println(""+i+" "+splitheder[i]);
            }

            String line = "";

            List<Filme> filmes = new ArrayList<>();

            while((line=bfr.readLine())!=null) {
                String spl[] = line.split(",");
                HashMap<String,Float> asVariaveis = new HashMap<String,Float>();

                String titulo = spl[7];

                float valorGenero = calculaValorGenero(spl[2]);
                grupoGenero.fuzzifica(valorGenero, asVariaveis);
                float valorTempo;
                try {
                    valorTempo = Float.parseFloat(spl[14]);
                }
                catch(Exception ex){
                    valorTempo = 0;
                }
                grupoTempoDuracao.fuzzifica(valorTempo, asVariaveis);

                float valorOrcamento;
                try{
                    valorOrcamento = Float.parseFloat(spl[1]);
                }
                catch (Exception ex){
                    valorOrcamento = 0;
                }
                grupoOrcamento.fuzzifica(valorOrcamento, asVariaveis);

                // Extrai o ano da data (spl[12]) e converte para float
                float valorEpoca;
                try{
                    valorEpoca = extrairAno(spl[12]);
                }
                catch (Exception ex){
                    valorEpoca = 0;
                }
                grupoEpoca.fuzzifica(valorEpoca, asVariaveis);

                float valorPopularidade;
                try {
                    valorPopularidade = Float.parseFloat(spl[9]);
                }
                catch(Exception ex){
                    valorPopularidade = 0;
                }
                grupoPopularidade.fuzzifica(valorPopularidade, asVariaveis);

                //Regras Genero x Tempo de duracao
                rodaRegraE(asVariaveis, "Obra prima", "Muito longo", "Muito atrativo");
                rodaRegraE(asVariaveis, "Obra prima", "Ideal", "Muito atrativo");
                rodaRegraE(asVariaveis, "Obra prima", "Muito curto", "Muito atrativo");
                rodaRegraE(asVariaveis, "Bom", "Muito longo", "Atrativo");
                rodaRegraE(asVariaveis, "Bom", "Ideal", "Muito atrativo");
                rodaRegraE(asVariaveis, "Bom", "Muito curto", "Atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Muito longo", "Nada atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Ideal", "Atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Muito curto", "Nada atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Muito longo", "Nada atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Ideal", "Nada atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Muito curto", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Muito longo", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Ideal", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Muito curto", "Nada atrativo");

                //Regras Genero x Popularidade
                rodaRegraOU(asVariaveis, "Obra prima", "Obscuro", "Atrativo");
                rodaRegraOU(asVariaveis, "Obra prima", "Emergente", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Obra prima", "Viral", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Obra prima", "Fenomeno", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Bom", "Obscuro", "Atrativo");
                rodaRegraOU(asVariaveis, "Bom", "Emergente", "Atrativo");
                rodaRegraOU(asVariaveis, "Bom", "Viral", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Bom", "Fenomeno", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Mediano", "Obscuro", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Mediano", "Emergente", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Mediano", "Viral", "Atrativo");
                rodaRegraOU(asVariaveis, "Mediano", "Fenomeno", "Muito atrativo");
                rodaRegraOU(asVariaveis, "Ruim", "Obscuro", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Ruim", "Emergente", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Ruim", "Viral", "Atrativo");
                rodaRegraOU(asVariaveis, "Ruim", "Fenomeno", "Atrativo");
                rodaRegraOU(asVariaveis, "Horrivel", "Obscuro", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Horrivel", "Emergente", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Horrivel", "Viral", "Nada atrativo");
                rodaRegraOU(asVariaveis, "Horrivel", "Fenomeno", "Atrativo");

                //Regras Genero x Epoca
                rodaRegraE(asVariaveis, "Obra prima", "Muito velho", "Nada atrativo");
                rodaRegraE(asVariaveis, "Obra prima", "Velho mediano", "Atrativo");
                rodaRegraE(asVariaveis, "Obra prima", "Novo ideal", "Muito atrativo");
                rodaRegraE(asVariaveis, "Bom", "Muito velho", "Nada atrativo");
                rodaRegraE(asVariaveis, "Bom", "Velho mediano", "Atrativo");
                rodaRegraE(asVariaveis, "Bom", "Novo ideal", "Muito atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Muito velho", "Nada atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Velho mediano", "Nada atrativo");
                rodaRegraE(asVariaveis, "Mediano", "Novo ideal", "Atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Muito velho", "Nada atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Velho mediano", "Nada atrativo");
                rodaRegraE(asVariaveis, "Ruim", "Novo ideal", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Muito velho", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Velho mediano", "Nada atrativo");
                rodaRegraE(asVariaveis, "Horrivel", "Novo ideal", "Nada atrativo");

                //Regras Orçamento x Epoca
                rodaRegraE(asVariaveis,"Micro orcamento","Muito velho","Nada atrativo");
                rodaRegraE(asVariaveis,"Micro orcamento","Velho mediano","Nada atrativo");
                rodaRegraE(asVariaveis,"Micro orcamento","Novo ideal","Nada atrativo");
                rodaRegraE(asVariaveis,"Baixo orcamento","Muito velho","Nada atrativo");
                rodaRegraE(asVariaveis,"Baixo orcamento","Velho mediano","Nada atrativo");
                rodaRegraE(asVariaveis,"Baixo orcamento","Novo ideal","Atrativo");
                rodaRegraE(asVariaveis,"Medio orcamento","Muito velho","Nada atrativo");
                rodaRegraE(asVariaveis,"Medio orcamento","Velho mediano","Atrativo");
                rodaRegraE(asVariaveis,"Medio orcamento","Novo ideal","Atrativo");
                rodaRegraE(asVariaveis,"Alto orcamento","Muito velho","Nada atrativo");
                rodaRegraE(asVariaveis,"Alto orcamento","Velho mediano","Atrativo");
                rodaRegraE(asVariaveis,"Alto orcamento","Novo ideal","Muito atrativo");

                //Regras Epoca x Popularidade
                rodaRegraOU(asVariaveis,"Novo ideal","Fenomeno","Muito atrativo");
                rodaRegraOU(asVariaveis,"Novo ideal","Viral","Muito atrativo");
                rodaRegraOU(asVariaveis,"Novo ideal","Emergente","Atrativo");
                rodaRegraOU(asVariaveis,"Novo ideal","Obscuro","Atrativo");
                rodaRegraOU(asVariaveis,"Velho mediano","Fenomeno","Muito atrativo");
                rodaRegraOU(asVariaveis,"Velho mediano","Viral","Atrativo");
                rodaRegraOU(asVariaveis,"Velho mediano","Emergente","Atrativo");
                rodaRegraOU(asVariaveis,"Velho mediano","Obscuro","Nada atrativo");
                rodaRegraOU(asVariaveis,"Muito velho","Fenomeno","Atrativo");
                rodaRegraOU(asVariaveis,"Muito velho","Viral","Atrativo");
                rodaRegraOU(asVariaveis,"Muito velho","Emergente","Nada atrativo");
                rodaRegraOU(asVariaveis,"Muito velho","Obscuro","Nada atrativo");

                float MA = asVariaveis.get("Muito atrativo");
                float A = asVariaveis.get("Atrativo");
                float NA = asVariaveis.get("Nada atrativo");

                float score = (NA*1.5f+A*7.0f+MA*9.5f)/(NA+A+MA);

                System.out.println("NA "+NA+" A "+A +" MA "+MA);
                System.out.println(titulo+ " -> " + score);

                filmes.add(new Filme(titulo, score));
            }

            Collections.sort(filmes, new Comparator<Filme>() {
                @Override
                public int compare(Filme f1, Filme f2) {
                    return Float.compare(f2.getNota(), f1.getNota()); // Ordena em ordem decrescente
                }
            });

            System.out.println("\n\nTop 10 filmes:");

            for(int i = 0; i < 10; i++){
                System.out.println("\n"+ (i + 1) + " - " + filmes.get(i).getTitulo() + "-- Score: " + filmes.get(i).getNota());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void rodaRegraE(HashMap<String, Float> asVariaveis,String var1,String var2,String varr) {
        float v = Math.min(asVariaveis.get(var1),asVariaveis.get(var2));
        if(asVariaveis.keySet().contains(varr)) {
            float vatual = asVariaveis.get(varr);
            asVariaveis.put(varr, Math.max(vatual, v));
        }else {
            asVariaveis.put(varr, v);
        }
    }

    private static void rodaRegraOU(HashMap<String, Float> asVariaveis,String var1,String var2,String varr) {
        float v = Math.max(asVariaveis.get(var1),asVariaveis.get(var2));
        if(asVariaveis.keySet().contains(varr)) {
            float vatual = asVariaveis.get(varr);
            asVariaveis.put(varr, Math.max(vatual, v));
        }else {
            asVariaveis.put(varr, v);
        }
    }

    private static float calculaValorGenero(String generos) {
        float nota = 0;
        float n = 0;

        Map<String, Float> notasGeneros = new HashMap<>();
        notasGeneros.put("Action", 69.0f);
        notasGeneros.put("Adventure", 85.0f);
        notasGeneros.put("Fantasy", 94.0f);
        notasGeneros.put("Science Fiction", 90.0f);
        notasGeneros.put("Crime", 38.0f);
        notasGeneros.put("Drama", 26.0f);
        notasGeneros.put("Thriller", 53.0f);
        notasGeneros.put("Comedy", 67.0f);
        notasGeneros.put("Animation", 77.0f);
        notasGeneros.put("Family", 10.0f);
        notasGeneros.put("Western", 61.0f);
        notasGeneros.put("Romance", 45.0f);
        notasGeneros.put("Horror", 20.0f);
        notasGeneros.put("Mystery", 42.0f);
        notasGeneros.put("History", 70.0f);
        notasGeneros.put("War", 80.0f);
        notasGeneros.put("Music", 0.0f);
        notasGeneros.put("Documentary", 33.0f);
        notasGeneros.put("Foreign", 30.0f);
        notasGeneros.put("TV Movie", 0.0f);

        for (Map.Entry<String, Float> entry : notasGeneros.entrySet()) {
            String genero = entry.getKey();
            float valorGenero = entry.getValue();

            if (generos.contains(genero)) {
                nota += valorGenero;
                n++;
            }
        }

        if (n > 0) {
            return nota / n;
        } else {
            return 0;
        }
    }
    // Método para extrair o ano da data e convertê-lo para float
    private static float extrairAno(String data) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy");

        if (data == null || data.equals("")) {
            return 0; // Retorna 0 se a data for nula
        }

        try {
            Date date = inputFormat.parse(data); // Converte a string para Date
            String ano = outputFormat.format(date); // Extrai o ano
            return Float.parseFloat(ano); // Converte o ano para float
        } catch (ParseException e) {
            return 0; // Retorna 0 em caso de erro
        }
    }
}
