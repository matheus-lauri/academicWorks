class Filme {
    private String titulo;
    private float nota;

    public Filme(String titulo, float nota) {
        this.titulo = titulo;
        this.nota = nota;
    }

    public String getTitulo() {
        return titulo;
    }

    public float getNota() {
        return nota;
    }

    @Override
    public String toString() {
        return "Filme{" +
                "titulo='" + titulo + '\'' +
                ", nota=" + nota +
                '}';
    }
}