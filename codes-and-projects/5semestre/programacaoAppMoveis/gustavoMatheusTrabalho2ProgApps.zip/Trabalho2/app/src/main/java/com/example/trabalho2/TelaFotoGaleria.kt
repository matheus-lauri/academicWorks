package com.example.trabalho2

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream


class TelaFotoGaleria : AppCompatActivity() {

    private val REQUEST_SELECT_IMAGE = 100
    private val REQUEST_TAKE_PHOTO = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_foto_galeria)

        // Get the CPF from the intent
        val cpf = intent.getStringExtra("cpf")

        val cpfTextResult = findViewById<TextView>(R.id.textView7)

        // Display the CPF in a TextView
        cpfTextResult.text = cpf

        val tirarFoto = findViewById<Button>(R.id.tirarFoto)
        val selecionarImagem = findViewById<Button>(R.id.selecionarImagem)

        val buttons = listOf(selecionarImagem, tirarFoto)

        buttons.forEach { button ->
            button.setOnClickListener {
                when (button) {
                    selecionarImagem -> {
                        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                        startActivityForResult(intent, REQUEST_SELECT_IMAGE)
                    }
                    tirarFoto -> {
                        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                        startActivityForResult(intent, REQUEST_TAKE_PHOTO)
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_SELECT_IMAGE -> {
                    val selectedImageUri = data?.data
                    compartilharImagem(selectedImageUri)
                }
                REQUEST_TAKE_PHOTO -> {
                    val bitmapImagem = data?.extras?.get("data") as Bitmap?
                    val nomeArquivoImagem = "image${System.currentTimeMillis()}.jpg"
                    val valoresContent = ContentValues().apply {
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                        put(MediaStore.MediaColumns.DISPLAY_NAME, nomeArquivoImagem)
                    }
                    var UriImagem: Uri? = null
                    var saidaImagem: OutputStream?
                    contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, valoresContent)?.also { uri ->
                        saidaImagem = contentResolver.openOutputStream(uri)
                        if (bitmapImagem != null) {
                            saidaImagem?.let { bitmapImagem.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                        }
                        saidaImagem?.close()
                        UriImagem = uri
                    }
                    compartilharImagem(UriImagem)
                }
            }
        }
    }

    private fun compartilharImagem(imageURI: Uri?){
        imageURI?.let {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, imageURI)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Compartilhar via"))
        }
    }

}
