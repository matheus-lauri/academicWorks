package com.example.trabalho2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class TelaLogin: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_login)

        val fazerLoginButton = findViewById<Button>(R.id.fazerLoginButton)
        val textCPF = findViewById<EditText>(R.id.textCPF)
        val textPassword = findViewById<EditText>(R.id.textPassword)

        fazerLoginButton.setOnClickListener {
            // Get the CPF and password from the EditText fields
            val cpf = textCPF.text.toString()
            val password = textPassword.text.toString()

            // Check if the credentials are correct
            if (cpf == "08993356912" && password == "123456") {
                // Navigate to the second screen
                val intent = Intent(this, TelaFotoGaleria::class.java)
                intent.putExtra("cpf", cpf)
                startActivity(intent)
            } else {
                // Show an alert message
                Toast.makeText(this, "Credenciais Inválidas", Toast.LENGTH_SHORT).show()
            }
        }

    }
}