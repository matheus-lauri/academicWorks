#include "schedule_edf.h"

// add a task to the list 
void add(char *name, int priority, int burst, int deadline){
   int x = 0;
}

// invoke the scheduler
void schedule(){
   int x = 0;
}
