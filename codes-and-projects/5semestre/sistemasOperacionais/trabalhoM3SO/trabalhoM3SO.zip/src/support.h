#ifndef SUPPORT_H
#define SUPPORT_H


char* padding(char *filename);

#endif