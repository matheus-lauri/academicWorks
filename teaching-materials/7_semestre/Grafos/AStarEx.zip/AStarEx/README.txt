Clicar em um bloco - coloca ou tira obstáculos
Clique + seta para cima - coloca início
Clique + seta para baixo - coloca fim
Espaço - ativa e desativa o modo passo a passo do algoritmo

D - Dijkstra
A + 1 - A* utilizando soma ortogonal
A + 2 - A* utilizando distância euclidiana
A + 3 - A* utilizando atalho diagonal

B + 4 - BFS utilizando soma ortogonal
B + 5 - BFS utilizando distância euclidiana
B + 6 - BFS utilizando atalho diagonal

C - Limpa os dados do algoritmo
R - Reseta para o estado inicial



Significado dos quadrados:

Branco - Espaço andável
Preto - Parede
Azul - Ponto inicial
Rosa - Ponto Final

Escala de vermelho - Aberto pelo algoritmo
Escala de verde - Visitado pelo algoritmo
Cinza - Caminho escolhido pelo algorimo