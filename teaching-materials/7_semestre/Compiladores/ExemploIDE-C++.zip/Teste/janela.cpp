#include "janela.h"
#include "ui_janela.h"

#include <QDebug>

#include "Lexico.h"
#include "Sintatico.h"
#include "Semantico.h"

Janela::Janela(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Janela)
{
    ui->setupUi(this);

}
Janela::~Janela()
{
    delete ui;
}

void Janela::tratarCliqueBotao() {


}
