================================================================================
ExemploIDE
================================================================================

Este projeto é um esboço e início de IDE mínima para a construção de um compilador 
integrado a um ambiente de programação.

O objetivo é facilitar o uso de interface gráfica em JAVA aos alunos para que possam 
integrar seus compiladores, alvos de desenvolvimento nos trabalhos elaborados na
disciplina de Compiladores do curso de Ciência da Computação da UNIVALI.

Este projeto foi elaborado pelo prof. Eduardo Alves da Silva e contém um formulário
gráfico usando a biblioteca Swing nativa do Java com:
  1. Janela principal baseada em um JFrame;
  2. Dois paineis com rolagem ativa (ScrollPane) para os componentes de texto;
  3. Um componente de texto para a entrada do código-fonte;
  4. Um componente de texto para a saída das mensagens geradas pelo compilador; e
  5. Um botão com o texto "Compilar" para acionar o compilador.

================================================================================
Livre para uso e atualização!
Mencione no desenvolvimento da IDE que o projeto é baseado no código disponibilizado
pelo professor.
================================================================================
